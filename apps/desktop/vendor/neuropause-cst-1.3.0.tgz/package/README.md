# @neuropause/cst 1.3.0

The executable half of **THE NEUROPAUSE MASTER SET — NPMS-1.4**.

Defined by **NPC-1.2, THE NEUROPAUSE CONSTITUTION**, which this package does not
restate. The volume states the assurance rules. This package enforces them. Where the two disagree,
neither wins automatically: the disagreement is a defect in one of them, and it is
recorded before either is changed.

    npm install
    npm run verify

`verify` runs, in order: build · base controls · base mutations · payment controls ·
simulation self-tests · payment mutations · adversarial simulation (strict rail) ·
prerequisite matrix · camera-delete controls · camera mutations · cross-process
exclusivity with real OS processes.

## What is measured — Node v22.22.2 · TypeScript 6.0.3 · 15 August 2026

```
base controls                 21/21 PASS · 16/16 mutations detected (NC-21, NC-23,
                              NC-26, NC-27 assert acceptances or type-level properties)
payment controls      (C3)    16/16 PASS · 15/15 mutations detected
camera delete controls (C4)    9/9  PASS ·  8/8  mutations detected
simulation self-tests         10/10 PASS
adversarial simulation        400 seeded scenarios · 80 restarts · 0 violations
prerequisite matrix           8 cells · duplicates ONLY where PG-09=0 ∧ PG-08=0
cross-process exclusivity     8 OS processes · 1 winner · SIGKILL · lease takeover

43 negative controls, 39 with a proven detection.
Independent review: NOT DONE — self-validation and mutation are not a substitute.
DETECTION COMPLETENESS: NOT ESTABLISHED.
```

## The one call site

```ts
const kernel = new CstKernel({ time, policy, claims, idempotency, resources, evidence, reconcile });
const outcome = await kernel.run(request, effect);
```

`effect` is the only place a real side effect lives. Everything before it is the
kernel; everything after it is verification.

## Two store families

`stores.ts` is in-memory — it makes the execution ORDER provable without a database.
`durable.ts` is SQLite (`node:sqlite`, WAL, `busy_timeout`) with atomic claim,
lease-bounded takeover and fencing tokens — it is what survives a `SIGKILL`.
Choose by deployment, not by convenience. Multi-**host** ownership is
**NOT ESTABLISHED**; the SQLite store is one host, one file.

## Guards

`Guards` exists so the mutation suite can prove each control detects its own removal.
There is **no supported production configuration in which a guard is off**. A guard
that must be disabled to ship is an exception object with an owner, a risk, an expiry
and a monitoring plan — recorded next to a control that still reads `FAIL`.

## What this package does NOT establish

Real ERP integration · real payment-rail capabilities · real NeuroLook integration ·
multi-host ownership · NeuroChain hash linkage · Action Firewall as a module boundary ·
detection completeness. See NPMS-1.4 Book VII §7.5.
