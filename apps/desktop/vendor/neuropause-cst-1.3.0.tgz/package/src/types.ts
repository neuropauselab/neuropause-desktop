/**
 * NP-CANON-1.0 Part II — typed identifiers and closed vocabularies.
 *
 * MSD-078: governed identifiers are distinctly typed. `ApprovalId` and
 * `ExecutionId` being both `string` is how the wrong one gets passed.
 */

/**
 * NP-CST-LAW-02 — the sentinel for "the authoritative source could not tell us".
 * It exists so that an unobservable post-state cannot be compared against the
 * expected one and come out as DEVIATION. Not knowing whether the state matches
 * is not knowing that it differs.
 */
export const UNOBSERVABLE = 'NP:UNOBSERVABLE' as const;

export type Brand<T, B extends string> = T & { readonly __brand: B };

export type TransitionId = Brand<string, 'TransitionId'>;
export type RequestId = Brand<string, 'RequestId'>;
export type ExecutionId = Brand<string, 'ExecutionId'>;
export type ApprovalId = Brand<string, 'ApprovalId'>;
export type EvidenceId = Brand<string, 'EvidenceId'>;
export type IdempotencyKey = Brand<string, 'IdempotencyKey'>;
export type FencingToken = Brand<number, 'FencingToken'>;

export const transitionId = (s: string) => s as TransitionId;
export const requestId = (s: string) => s as RequestId;
export const executionId = (s: string) => s as ExecutionId;
export const approvalId = (s: string) => s as ApprovalId;
export const idempotencyKey = (s: string) => s as IdempotencyKey;

/** NP-CST-48 — governance verdicts. Closed. No competing verdict system. */
export type Verdict = 'ALLOW' | 'HOLD' | 'DENY' | 'ESCALATE';

/** NP-CST-37 — verification outcomes. UNKNOWN is mandatory and is not SAFE. */
export type VerificationOutcome = 'VERIFIED' | 'DEVIATION' | 'UNKNOWN';

/** NP-CST-15 — consequence classes. */
export type Consequence = 'C0' | 'C1' | 'C2' | 'C3' | 'C4';

/** NP-CST-16 — reversibility is separate from consequence. */
export type Reversibility =
  | 'REVERSIBLE' | 'PARTIALLY_REVERSIBLE' | 'DIFFICULT_TO_REVERSE'
  | 'IRREVERSIBLE' | 'UNKNOWN';

export type ActorType = 'HUMAN' | 'AI' | 'SERVICE' | 'CONNECTOR' | 'WORKFLOW' | 'ROBOT';

/**
 * MSD-111 — the closed reason vocabulary. A generic denial turns a five-minute
 * diagnosis into a debugging session.
 */
export type ReasonCode =
  | 'OK'
  | 'IDENTITY_UNRESOLVED'
  | 'AUTHORIZATION_FAILURE'
  | 'TENANT_ISOLATION_VIOLATION'
  | 'PURPOSE_MISSING'
  | 'APPROVAL_REQUIRED'
  | 'APPROVAL_MISMATCH'
  | 'APPROVAL_SCOPE_VIOLATION'
  | 'APPROVAL_EXPIRED'
  | 'APPROVAL_CONSUMED'
  | 'EVIDENCE_STALE'
  | 'CLAIM_LOST'
  | 'IDEMPOTENCY_HELD'
  | 'RECONCILIATION_REQUIRED'
  | 'RELATIONSHIP_CONTEXT_MISSING'
  | 'RELATIONSHIP_CONTEXT_STALE'
  | 'RELATIONSHIP_EPISTEMIC_INSUFFICIENT'
  | 'OBSERVATION_SUBJECT_MISMATCH'
  | 'OUTCOME_UNKNOWN'
  | 'CONSTRAINT_EXCEEDED'   // was AMOUNT_NOT_AUTHORIZED — RETIRED: one word, two meanings
  | 'STALE_RESOURCE_VERSION'
  | 'STALE_POLICY'
  | 'MODEL_SELF_AUTHORIZATION'
  | 'SEPARATION_OF_DUTIES'
  | 'POSTCONDITION_UNDECLARED'
  | 'RECOVERY_UNGOVERNED';

export interface ResourceIdentity {
  readonly tenantId: string;
  readonly resourceType: string;
  readonly resourceId: string;
  readonly version: number;
}

export interface Actor {
  readonly id: string;
  readonly type: ActorType;
  readonly tenantId: string;
}

/** NP-CST-96 — an approval binds nine things. Fewer is generic authority. */
export interface Approval {
  readonly approvalId: ApprovalId;
  readonly transitionId: TransitionId;
  readonly approver: Actor;
  readonly action: string;
  readonly scope: Omit<ResourceIdentity, 'version'>;
  readonly resourceVersion: number;
  readonly purpose: string;
  readonly policyVersion: string;
  readonly issuedAt: number;
  readonly expiresAt: number;
  /**
   * Declared numeric ceilings, evaluated INSIDE the gate. Keys are `max<Name>`;
   * the request must carry a matching `quantities.<name>`. Generic on purpose —
   * the kernel enforces the ceiling without knowing what an amount is.
   */
  readonly constraints?: Readonly<Record<string, number>>;
  consumed: boolean;
}

export interface EvidenceRef {
  readonly evidenceId: EvidenceId;
  readonly source: string;
  readonly observedAt: number;
  /** NP-CST-137 equivalent: freshness is declared BY THE CONSUMER. */
  readonly freshnessRequirementMs: number;
}

/**
 * NPC-1.0 §4 — a CST is not a flat action object. WHO may act, WHAT the action
 * affects, WHICH evidence is relevant and WHAT consequences propagate are all
 * determined by relationships, not by the action name. A transition that carries
 * no relationship context has not been understood, only received.
 */
/**
 * NPL-17 — "not assessed", "assessed and absent", "stale" and "unknown" are FOUR
 * DISTINCT STATES. Collapsing any two lets "nobody looked" read as "none exists".
 * This vocabulary is deliberately reusable: it applies to authority, evidence,
 * dependencies, external state, identity, ownership, post-state and source
 * availability, not only to relationships.
 */
export type AssessmentState =
  | 'UNASSESSED'            // nobody looked
  | 'ASSESSED_NONE_FOUND'   // looked; nothing applies — this is an ANSWER
  | 'ASSESSED_FOUND'        // looked; found
  | 'STALE'                 // looked, too long ago to rely on
  | 'UNKNOWN'               // the source declined to answer
  | 'NOT_APPLICABLE';       // the profile does not require this assessment

/**
 * NPL-16 / NPC epistemic status. An asserted fact is not an observed one, and a
 * model's fluent account of a relationship is not evidence that it holds.
 */
export type EpistemicStatus =
  | 'OBSERVED' | 'DERIVED' | 'INFERRED' | 'DECLARED' | 'ASSUMED' | 'UNKNOWN' | 'CONTRADICTED';

export interface RelationshipRef {
  /** e.g. 'owns' | 'employs' | 'is-guardian-of' | 'depends-on' | 'delegated-by' */
  readonly kind: string;
  readonly subject: string;
  readonly object: string;
  /** where this relationship was read from — never inferred by the kernel */
  readonly source: string;
  /** when the source last confirmed it; compared against policy freshness */
  readonly observedAt: number;
  /**
   * How this relation came to be believed. Defaults to OBSERVED when omitted for
   * backward compatibility, but a profile MAY refuse INFERRED or ASSUMED
   * relations for high-consequence actions.
   */
  readonly epistemicStatus?: EpistemicStatus;
}

export interface TransitionRequest {
  readonly transitionId: TransitionId;
  readonly requestId: RequestId;
  readonly actor: Actor;
  readonly action: string;
  readonly target: ResourceIdentity;
  readonly purpose: string;
  readonly intent: string;
  /**
   * NPC-1.0 §4 / NP-NC-20. Required where policy declares it. An EMPTY ARRAY is
   * a declaration that none applies and is accepted; OMISSION is not — the two
   * must stay distinguishable, or "nobody looked" reads as "none exists" (L-07).
   */
  readonly relationships?: readonly RelationshipRef[];
  /** NP-CST-35 — declared BEFORE execution, never derived from the result. */
  readonly expectedPostState: unknown;
  readonly consequence: Consequence;
  readonly reversibility: Reversibility;
  readonly policyVersion: string;
  readonly idempotencyKey: IdempotencyKey;
  readonly evidence: readonly EvidenceRef[];
  /** Named quantities the approval's `max<Name>` constraints bound. */
  readonly quantities?: Readonly<Record<string, number>>;
  readonly approval?: Approval;
  readonly recoveryOf?: TransitionId;
}

/** NP-CST-18 — the envelope. Nothing is omitted; NOT_APPLICABLE is explicit. */
export interface TransitionOutcome {
  readonly transitionId: TransitionId;
  readonly verdict: Verdict;
  readonly reason: ReasonCode;
  readonly claimed: boolean;
  readonly fencingToken: FencingToken | null;
  readonly executed: boolean;
  readonly executionId: ExecutionId | null;
  readonly duplicateSuppressed: boolean;
  readonly observedPostState: unknown;
  readonly verification: VerificationOutcome | 'NOT_APPLICABLE';
  readonly deviation: { expected: unknown; observed: unknown } | null;
  readonly timeline: Readonly<Record<string, number>>;
  /**
   * NPL-17 — reported on EVERY outcome, including outcomes where the profile did
   * not require the assessment. A silent field would make NOT_APPLICABLE and
   * UNASSESSED indistinguishable to a reader of the record, which is the exact
   * collapse this vocabulary exists to prevent.
   */
  readonly relationshipAssessment: AssessmentState;
  /**
   * NPL-22 — VERIFIED is meaningless without a proposition. "Verified what,
   * against which expected condition, from which source, at what time, under
   * what scope?" A verdict that cannot answer those five questions is a word,
   * not a finding. Null ONLY where no verification was attempted.
   */
  readonly verificationProposition: VerificationProposition | null;
  /**
   * NPL-18..21 — the four outcome classes. `success` alone cannot express a
   * system that does not know, which is the state real systems spend most of
   * their incidents in.
   */
  readonly outcomeClass: OutcomeClass;
}

/** NPL-22 — what a verification verdict is a verdict ABOUT. */
export interface VerificationProposition {
  /** what was verified — the subject key, not a description */
  readonly subject: string;
  readonly expected: unknown;
  readonly observed: unknown;
  /** which authoritative source answered */
  readonly source: string;
  readonly at: number;
  /** the comparison relation used — never implied */
  readonly relation: 'STRUCTURAL_EQUALITY' | 'DECLARED_PREDICATE';
  readonly scope: string;
}

/**
 * NPL-18..21. VERIFIED_FAILURE is a POSITIVE finding — the expected outcome was
 * established as not achieved — and is distinct from UNKNOWN, where nothing was
 * established at all.
 */
export type OutcomeClass =
  | 'VERIFIED_SUCCESS'
  | 'VERIFIED_FAILURE'
  | 'DEVIATION'
  | 'UNKNOWN'
  | 'NOT_ATTEMPTED';
