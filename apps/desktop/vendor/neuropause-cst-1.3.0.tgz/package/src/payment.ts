/**
 * PH-8 — the ERP payment adapter.
 *
 * The kernel knows nothing about payments. Everything payment-specific lives
 * here, at ONE call site (MSD-297). The adapter's job is to translate the ERP's
 * own authoritative states into a transition envelope — it MUST NOT invent a
 * second payment state machine (the states below are placeholders to be
 * replaced by the ERP's real ones).
 */
import { CstKernel, type Effect, type Reconciler } from './kernel.js';
import type { EvidenceStore, ResourceStore, TimeSource } from './stores.js';
import {
  UNOBSERVABLE, idempotencyKey, requestId, transitionId,
  type Approval, type Actor, type IdempotencyKey, type TransitionOutcome,
  type TransitionRequest,
} from './types.js';

/** Replace with the ERP's authoritative payment states. Do not invent these. */
export type PaymentState =
  | 'READY_FOR_EXECUTION' | 'SUBMITTED' | 'SETTLED' | 'FAILED' | 'CANCELLED';

export interface PaymentCommand {
  readonly tenantId: string;
  readonly paymentId: string;
  readonly paymentVersion: number;
  readonly amountMinor: number;      // integer minor units — MSD-164, never a float
  readonly currency: string;
  readonly payeeId: string;
  readonly actor: Actor;
  readonly purpose: string;
  readonly approval?: Approval;
  readonly evidenceObservedAt: number;
  readonly evidenceFreshnessMs: number;
}

/**
 * The external payment rail. Three operations, because a real rail has three:
 * you submit, you read status, and — when a response is lost — you look the
 * attempt up by the key you sent.
 */
export interface PaymentProvider {
  submit(cmd: {
    idempotencyKey: string; amountMinor: number; currency: string;
    payeeId: string; fencingToken: number;
  }): Promise<{ accepted: boolean; providerRef?: string }>;
  /** NP-CST-39 — the authoritative read. Never the submit response. */
  statusOf(providerRef: string): Promise<PaymentState | 'UNKNOWN'>;
  /** NP-NC-13 — the ONLY way to resolve a lost response. */
  lookupByKey(key: string): Promise<{ found: boolean; providerRef?: string }>;
}

/**
 * NP-CST-105 — the key is derived from the INTENT, not from the attempt. Two
 * retries of one payment share it; two distinct payments never do. Amount and
 * payee are inside the derivation: a "retry" for a different amount is a
 * different intent and must not collide with the original.
 */
export const derivePaymentKey = (c: PaymentCommand): IdempotencyKey =>
  idempotencyKey(
    `pay:${c.tenantId}:${c.paymentId}:${c.amountMinor}:${c.currency}:${c.payeeId}`,
  );

export interface PaymentAdapterDeps {
  readonly kernel: CstKernel;
  readonly provider: PaymentProvider;
  readonly resources: ResourceStore;
  readonly time: TimeSource;
  readonly evidence: EvidenceStore;
}

export class ErpPaymentAdapter {
  #refs = new Map<string, string>();          // idempotencyKey → providerRef

  constructor(private readonly d: PaymentAdapterDeps) {}

  /** The reconciler the kernel calls on an unresolved replay. */
  reconciler: Reconciler = async (key) => {
    const hit = await this.d.provider.lookupByKey(String(key));
    if (!hit.found || !hit.providerRef) return { known: false };
    const status = await this.d.provider.statusOf(hit.providerRef);
    // The provider knows the attempt exists. Whether it SETTLED is still its
    // answer to give, not ours to assume.
    const verification =
      status === 'SETTLED' ? 'VERIFIED' : status === 'UNKNOWN' ? 'UNKNOWN' : 'DEVIATION';
    return {
      known: true,
      outcome: {
        transitionId: transitionId(`recon:${String(key)}`),
        verdict: 'ALLOW', reason: 'OK', claimed: true, fencingToken: null,
        executed: true, executionId: null, duplicateSuppressed: true,
        observedPostState: status, verification,
        deviation: verification === 'DEVIATION'
          ? { expected: 'SETTLED', observed: status } : null,
        timeline: Object.freeze({ reconciled: this.d.time.now() }),
        // NPL-17: a reconciliation reads the EXTERNAL system. It performs no
        // relationship assessment of its own, and says so rather than
        // inheriting the original transition's answer.
        relationshipAssessment: 'NOT_APPLICABLE',
        // NPL-22 — a reconciliation IS a verification, so it carries its
        // proposition. NPL-18: what the external system established.
        verificationProposition: {
          subject: String(key), expected: 'RECONCILED', observed: 'RECONCILED',
          source: 'external:reconciliation', at: this.d.time.now(),
          relation: 'DECLARED_PREDICATE', scope: 'reconcile-by-key',
        },
        outcomeClass: 'VERIFIED_SUCCESS',
      } satisfies TransitionOutcome,
    };
  };

  buildRequest(c: PaymentCommand): TransitionRequest {
    const tid = transitionId(`pay-${c.tenantId}-${c.paymentId}`);
    return {
      transitionId: tid,
      requestId: requestId(`req-${c.paymentId}`),
      actor: c.actor,
      action: 'PAYMENT.EXECUTE',
      target: {
        tenantId: c.tenantId, resourceType: 'payment',
        resourceId: c.paymentId, version: c.paymentVersion,
      },
      purpose: c.purpose,
      intent: `execute payment ${c.paymentId} of ${c.amountMinor} ${c.currency} to ${c.payeeId}`,
      expectedPostState: 'SETTLED' satisfies PaymentState,
      consequence: 'C3',
      reversibility: 'DIFFICULT_TO_REVERSE',
      policyVersion: 'erp-policy:v4',
      idempotencyKey: derivePaymentKey(c),
      quantities: { amountMinor: c.amountMinor },
      evidence: [{
        evidenceId: `ev-${c.paymentId}` as never,
        source: 'erp-ledger',
        observedAt: c.evidenceObservedAt,
        freshnessRequirementMs: c.evidenceFreshnessMs,
      }],
      ...(c.approval ? { approval: c.approval } : {}),
    };
  }

  /** The one call site. Everything before the effect is the kernel. */
  async execute(c: PaymentCommand): Promise<TransitionOutcome> {
    const req = this.buildRequest(c);

    const effect: Effect = async (r, token) => {
      const res = await this.d.provider.submit({
        idempotencyKey: String(r.idempotencyKey),
        amountMinor: c.amountMinor, currency: c.currency,
        payeeId: c.payeeId, fencingToken: token,
      });
      if (res.providerRef) {
        this.#refs.set(String(r.idempotencyKey), res.providerRef);
        // The ERP's own record advances; the CST layer does not own this state.
        const status = await this.d.provider.statusOf(res.providerRef);
        // Never write the rail's 'UNKNOWN' in as if it were a state.
        this.d.resources.put({ ...r.target }, status === 'UNKNOWN' ? UNOBSERVABLE : status);
      }
      return { accepted: res.accepted };
    };

    return this.d.kernel.run(req, effect);
  }

  /**
   * NP-CST-43 — recovery is itself a CST. It does not call the rail directly;
   * it re-enters the kernel carrying `recoveryOf`.
   */
  async recover(c: PaymentCommand, of: TransitionRequest['transitionId']): Promise<TransitionOutcome> {
    const req: TransitionRequest = { ...this.buildRequest(c), recoveryOf: of };
    const effect: Effect = async (r, token) => {
      const res = await this.d.provider.submit({
        idempotencyKey: String(r.idempotencyKey), amountMinor: c.amountMinor,
        currency: c.currency, payeeId: c.payeeId, fencingToken: token,
      });
      return { accepted: res.accepted };
    };
    return this.d.kernel.run(req, effect);
  }

  providerRefFor(key: IdempotencyKey): string | undefined {
    return this.#refs.get(String(key));
  }
}
