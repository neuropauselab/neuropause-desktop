/**
 * §18 capability contract and §27 shadow mode.
 *
 * Two rules drive the shapes here:
 *
 *  1. The adapter declares what the rail ACTUALLY supports, not what NeuroPause
 *     wishes it supported. An undeclared capability is absent.
 *  2. Shadow mode must be structurally incapable of executing. `if (shadow)
 *     return` is a branch someone deletes; a recorder that holds no reference to
 *     the provider cannot call it even by mistake.
 */
import type { Effect } from './kernel.js';
import type { FencingToken, TransitionRequest } from './types.js';

// ---------------------------------------------------------------- capabilities

/**
 * NP-PG-08. Every field defaults to FALSE: a capability nobody recorded evidence
 * for does not exist. `lookupReliability` is deliberately a measured number, not
 * a boolean — "it usually works" is the answer that produced the three residual
 * duplicate settlements.
 */
export interface PaymentRailCapabilities {
  readonly provider: string;
  readonly documentationUrl: string;
  readonly documentationVersion: string;
  readonly verifiedOn: string;                 // ISO date of the evidence
  readonly verifiedBy: string;
  readonly deduplicatesByIdempotencyKey: boolean;
  readonly lookupByIdempotencyKey: boolean;
  /** observed success rate of lookup, 0..1, from a recorded test — not an opinion */
  readonly lookupReliability: number;
  readonly durableExternalReference: boolean;
  readonly authoritativeStateQuery: boolean;
  readonly supportsReconciliation: boolean;
  /** identifier of the test evidence supporting the fields above */
  readonly evidenceRef: string;
}

export const UNDECLARED_RAIL: PaymentRailCapabilities = Object.freeze({
  provider: 'UNDECLARED', documentationUrl: '', documentationVersion: '',
  verifiedOn: '', verifiedBy: '',
  deduplicatesByIdempotencyKey: false, lookupByIdempotencyKey: false,
  lookupReliability: 0, durableExternalReference: false,
  authoritativeStateQuery: false, supportsReconciliation: false,
  evidenceRef: '',
});

export interface PromotionInput {
  readonly rail: PaymentRailCapabilities;
  readonly durableIntent: boolean;            // NP-PG-09
  readonly crossProcessOwnership: boolean;    // NP-PG-10
  readonly erpStatesMapped: boolean;          // NP-PG-11
}

export interface PromotionDecision {
  readonly permitted: boolean;
  readonly blocking: readonly string[];
  readonly rationale: string;
}

/**
 * The measured condition, not the assumed one. The matrix run showed duplicate
 * settlements occur only when the intent record is volatile AND the rail can
 * neither dedupe nor be looked up — so the duplicate-effect prerequisite is a
 * DISJUNCTION, and stating it as a conjunction would block a configuration
 * measured to be safe.
 *
 * NP-PG-10 is still required for promotion, but on its own ground: cross-process
 * exclusivity. The matrix has no power over it and must not be cited for it.
 */
export function evaluatePromotion(i: PromotionInput): PromotionDecision {
  const blocking: string[] = [];

  const railCapable =
    i.rail.deduplicatesByIdempotencyKey
    || (i.rail.lookupByIdempotencyKey && i.rail.lookupReliability >= 1);

  if (!(i.durableIntent || railCapable)) {
    blocking.push('NP-PG-08/09 duplicate-effect prerequisite: neither a durable intent record '
      + 'nor a rail that dedupes or is reliably lookup-able');
  }
  if (!i.rail.authoritativeStateQuery) {
    blocking.push('NP-PG-08 no authoritative state query: verification would rest on the '
      + 'submit response, which NP-CST-36 prohibits');
  }
  if (!i.crossProcessOwnership) {
    blocking.push('NP-PG-10 cross-process exclusivity NOT ESTABLISHED');
  }
  if (!i.erpStatesMapped) {
    blocking.push('NP-PG-11 ERP payment states not mapped — placeholders in use');
  }
  if (!i.rail.evidenceRef || !i.rail.verifiedOn) {
    blocking.push('NP-PG-08 capabilities asserted without recorded evidence');
  }

  return {
    permitted: blocking.length === 0,
    blocking,
    rationale: blocking.length === 0
      ? 'every prerequisite satisfied with recorded evidence'
      : `${blocking.length} blocking prerequisite(s); promotion is conjunctive`,
  };
}

// ----------------------------------------------------------------- shadow mode

export interface ShadowRecord {
  readonly transitionId: string;
  readonly idempotencyKey: string;
  readonly wouldExecute: true;
  readonly at: number;
}

/**
 * The shadow effect. It receives no provider, holds no client, and has no code
 * path that reaches a rail — so "accidentally executing in shadow mode" is not a
 * bug that can be introduced by deleting a condition.
 */
export class ShadowEffect {
  readonly records: ShadowRecord[] = [];
  constructor(private readonly now: () => number) {}

  readonly effect: Effect = async (req: TransitionRequest, _token: FencingToken) => {
    this.records.push({
      transitionId: String(req.transitionId),
      idempotencyKey: String(req.idempotencyKey),
      wouldExecute: true,
      at: this.now(),
    });
    // Deliberately reports NOT accepted: nothing happened, and a shadow run must
    // never produce an outcome that reads like a successful execution.
    return { accepted: false };
  };
}

export interface ShadowSummary {
  evaluated: number;
  allow: number; hold: number; deny: number; escalate: number;
  wouldExecute: number;
  byReason: Record<string, number>;
}

export function summariseShadow(
  outcomes: readonly { verdict: string; reason: string }[],
  shadow: ShadowEffect,
): ShadowSummary {
  const byReason: Record<string, number> = {};
  let allow = 0, hold = 0, deny = 0, escalate = 0;
  for (const o of outcomes) {
    byReason[o.reason] = (byReason[o.reason] ?? 0) + 1;
    if (o.verdict === 'ALLOW') allow++;
    else if (o.verdict === 'HOLD') hold++;
    else if (o.verdict === 'DENY') deny++;
    else escalate++;
  }
  return {
    evaluated: outcomes.length, allow, hold, deny, escalate,
    wouldExecute: shadow.records.length, byReason,
  };
}
