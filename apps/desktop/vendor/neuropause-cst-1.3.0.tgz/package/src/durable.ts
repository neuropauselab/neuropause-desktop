/**
 * NP-PG-09 / NP-PG-10 — durable intent and cross-process atomic ownership.
 *
 * Backed by SQLite so that both properties are established by the STORE, not by
 * the kernel's control flow:
 *
 *   durability   the row survives the process that wrote it
 *   exclusivity  `INSERT ... ` on a PRIMARY KEY is a single-winner operation
 *                at the storage engine, not a check-then-act in application code
 *
 * `Durability ≠ Exclusivity ≠ Idempotency ≠ Verification` — four separate
 * controls, which is why they are four separate tables and four separate
 * methods here.
 *
 * SCOPE: a single SQLite file is a single host. This closes NP-PG-09, and
 * closes NP-PG-10 only for processes sharing that file. A multi-host deployment
 * needs a store with the same single-winner guarantee across hosts; the
 * interface below is what such a store must satisfy.
 */
import { DatabaseSync } from 'node:sqlite';
import type { ClaimResult } from './stores.js';
import type { FencingToken, IdempotencyKey } from './types.js';

export class DurableStore {
  readonly #db: DatabaseSync;

  constructor(path = ':memory:') {
    this.#db = new DatabaseSync(path);
    this.#db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA busy_timeout = 5000;
      CREATE TABLE IF NOT EXISTS claims (
        key TEXT PRIMARY KEY,
        owner TEXT NOT NULL,
        token INTEGER NOT NULL,
        claimed_at INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS tokens (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        next INTEGER NOT NULL
      );
      INSERT OR IGNORE INTO tokens (id, next) VALUES (1, 1);
      CREATE TABLE IF NOT EXISTS intents (
        key TEXT PRIMARY KEY,
        state TEXT NOT NULL,
        outcome TEXT
      );
    `);
  }

  close(): void { this.#db.close(); }

  // ---------------------------------------------------------------- ownership

  /**
   * NP-CST-28 — single-winner. The uniqueness constraint decides, not a read
   * followed by a write. Two processes racing on the same key: one INSERT
   * succeeds, the other raises a constraint violation. There is no window.
   */
  claimAtomic(key: string, owner: string): ClaimResult {
    const tokenRow = this.#db.prepare('SELECT next FROM tokens WHERE id = 1').get() as { next: number };
    const token = tokenRow.next;
    try {
      this.#db.prepare('INSERT INTO claims (key, owner, token, claimed_at) VALUES (?, ?, ?, ?)').run(key, owner, token, Date.now());
      this.#db.prepare('UPDATE tokens SET next = ? WHERE id = 1').run(token + 1);
      return { won: true, owner, fencingToken: token as FencingToken };
    } catch {
      const held = this.#db.prepare('SELECT owner, token FROM claims WHERE key = ?').get(key) as
        { owner: string; token: number } | undefined;
      return {
        won: false,
        owner: held?.owner ?? 'unknown',
        fencingToken: (held?.token ?? 0) as FencingToken,
      };
    }
  }

  /** Retained so the mutation suite can show the prohibited form still fails. */
  async claimCheckThenAct(key: string, owner: string): Promise<ClaimResult> {
    const held = this.#db.prepare('SELECT owner, token FROM claims WHERE key = ?').get(key) as
      { owner: string; token: number } | undefined;
    await Promise.resolve();
    if (held) return { won: false, owner: held.owner, fencingToken: held.token as FencingToken };
    const tokenRow = this.#db.prepare('SELECT next FROM tokens WHERE id = 1').get() as { next: number };
    const token = tokenRow.next;
    try {
      this.#db.prepare('INSERT INTO claims (key, owner, token, claimed_at) VALUES (?, ?, ?, ?)').run(key, owner, token, Date.now());
    } catch { /* the race the required form does not have */ }
    this.#db.prepare('UPDATE tokens SET next = ? WHERE id = 1').run(token + 1);
    return { won: true, owner, fencingToken: token as FencingToken };
  }

  /**
   * NP-CST-30 — a lease-bounded takeover. A holder that dies keeps its row
   * forever unless the claim carries an expiry, so a crashed worker would block
   * its transition permanently. Takeover issues a NEW fencing token, which is
   * what makes the stale holder's late write rejectable.
   */
  takeoverIfExpired(key: string, owner: string, now: number, leaseMs: number): ClaimResult | null {
    const held = this.#db.prepare('SELECT owner, token, claimed_at FROM claims WHERE key = ?').get(key) as
      { owner: string; token: number; claimed_at: number } | undefined;
    if (!held) return null;
    if (now - held.claimed_at < leaseMs) return null;          // still live
    const tokenRow = this.#db.prepare('SELECT next FROM tokens WHERE id = 1').get() as { next: number };
    const token = tokenRow.next;
    const r = this.#db.prepare('UPDATE claims SET owner = ?, token = ?, claimed_at = ? WHERE key = ? AND token = ?')
      .run(owner, token, now, key, held.token);
    if (Number(r.changes) === 0) return null;                   // someone else took it first
    this.#db.prepare('UPDATE tokens SET next = ? WHERE id = 1').run(token + 1);
    return { won: true, owner, fencingToken: token as FencingToken };
  }

  /** NP-CST-100 — ownership-checked release. */
  release(key: string, owner: string): boolean {
    const r = this.#db.prepare('DELETE FROM claims WHERE key = ? AND owner = ?').run(key, owner);
    return Number(r.changes) > 0;
  }

  holderOf(key: string): { owner: string; token: number } | null {
    return (this.#db.prepare('SELECT owner, token FROM claims WHERE key = ?').get(key) as { owner: string; token: number } | undefined) ?? null;
  }

  currentToken(key: string): number | null {
    const row = this.#db.prepare('SELECT token FROM claims WHERE key = ?').get(key) as
      { token: number } | undefined;
    return row?.token ?? null;
  }

  // ------------------------------------------------------------------- intent

  /** NP-CST-106 — written before the external effect, and it OUTLIVES the process. */
  acquire(key: IdempotencyKey): { fresh: boolean; state: 'IN_FLIGHT' | 'DONE'; outcome?: unknown } {
    const row = this.#db.prepare('SELECT state, outcome FROM intents WHERE key = ?').get(String(key)) as
      { state: string; outcome: string | null } | undefined;
    if (row) {
      return {
        fresh: false,
        state: row.state as 'IN_FLIGHT' | 'DONE',
        ...(row.outcome ? { outcome: JSON.parse(row.outcome) as unknown } : {}),
      };
    }
    this.#db.prepare("INSERT INTO intents (key, state, outcome) VALUES (?, 'IN_FLIGHT', NULL)")
      .run(String(key));
    return { fresh: true, state: 'IN_FLIGHT' };
  }

  complete(key: IdempotencyKey, outcome: unknown): void {
    this.#db.prepare("INSERT INTO intents (key, state, outcome) VALUES (?, 'DONE', ?) "
      + "ON CONFLICT(key) DO UPDATE SET state = 'DONE', outcome = excluded.outcome")
      .run(String(key), JSON.stringify(outcome));
  }

  release_intent(key: IdempotencyKey): void {
    this.#db.prepare("DELETE FROM intents WHERE key = ? AND state = 'IN_FLIGHT'").run(String(key));
  }
}

/** Adapts DurableStore to the kernel's IdempotencyStore shape. */
export class DurableIdempotencyStore {
  constructor(private readonly s: DurableStore) {}
  acquire(key: IdempotencyKey) { return this.s.acquire(key); }
  complete(key: IdempotencyKey, outcome: unknown) { this.s.complete(key, outcome); }
  release(key: IdempotencyKey) { this.s.release_intent(key); }
}

/** Adapts DurableStore to the kernel's ClaimStore shape. */
export class DurableClaimStore {
  constructor(private readonly s: DurableStore) {}
  claimAtomic(key: string, owner: string) { return this.s.claimAtomic(key, owner); }
  claimCheckThenAct(key: string, owner: string) { return this.s.claimCheckThenAct(key, owner); }
  release(key: string, owner: string) { return this.s.release(key, owner); }
  currentToken(key: string) { return this.s.currentToken(key); }
}
