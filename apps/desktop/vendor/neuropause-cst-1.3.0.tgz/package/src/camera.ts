/**
 * PH-9 — NeuroLook camera delete.  C4 · IRREVERSIBLE.
 *
 * The kernel is UNCHANGED from PH-8. Only this adapter differs. That is the
 * claim PH-9 exists to test: one governance grammar, two consequence domains.
 *
 * The domain difference that matters: a payment is verified by observing a
 * POSITIVE state (SETTLED). A deletion has no positive state to observe — and
 * "not found" is indistinguishable from "never existed" and from "the backend
 * could not answer". Verifying a deletion by absence is NP-CST-41 (absence is
 * not health) applied to verification, and it is wrong. A deletion must be
 * confirmed by a TOMBSTONE the backend issues.
 */
import { CstKernel, type Effect, type Reconciler } from './kernel.js';
import type { EvidenceStore, ResourceStore, TimeSource } from './stores.js';
import {
  UNOBSERVABLE, idempotencyKey, requestId, transitionId,
  type Approval, type Actor, type TransitionOutcome, type TransitionRequest,
} from './types.js';

export type CameraState = 'ACTIVE' | 'RETIRED' | 'DELETED';

/** What the backend returns when asked about a camera after a delete. */
export type CameraProbe =
  | { kind: 'PRESENT'; state: CameraState }
  | { kind: 'TOMBSTONE'; deletedAt: number; by: string }   // positive confirmation
  | { kind: 'NOT_FOUND' }                                   // proves nothing
  | { kind: 'UNREACHABLE' };

export interface CameraStore {
  delete(cmd: { idempotencyKey: string; cameraId: string; fencingToken: number }):
    Promise<{ accepted: boolean; receipt?: string }>;
  probe(cameraId: string): Promise<CameraProbe>;
  lookupByKey(key: string): Promise<{ found: boolean; receipt?: string }>;
}

export interface CameraCommand {
  readonly tenantId: string;
  readonly cameraId: string;
  readonly cameraVersion: number;
  readonly retentionDaysRemaining: number;   // a declared ceiling, enforced in-gate
  readonly actor: Actor;
  readonly purpose: string;
  readonly approval?: Approval;
  readonly evidenceObservedAt: number;
  readonly evidenceFreshnessMs: number;
}

export const deriveCameraKey = (c: CameraCommand) =>
  idempotencyKey(`camdel:${c.tenantId}:${c.cameraId}:${c.cameraVersion}`);

export class NeuroLookCameraAdapter {
  constructor(private readonly d: {
    kernel: CstKernel; store: CameraStore; resources: ResourceStore;
    time: TimeSource; evidence: EvidenceStore;
  }) {}

  reconciler: Reconciler = async (key) => {
    const hit = await this.d.store.lookupByKey(String(key));
    if (!hit.found) return { known: false };
    return {
      known: true,
      outcome: {
        transitionId: transitionId(`recon:${String(key)}`),
        verdict: 'ALLOW', reason: 'OK', claimed: true, fencingToken: null,
        executed: true, executionId: null, duplicateSuppressed: true,
        observedPostState: 'DELETED', verification: 'VERIFIED', deviation: null,
        timeline: Object.freeze({ reconciled: this.d.time.now() }),
        // NPL-17: a reconciliation reads the EXTERNAL system. It performs no
        // relationship assessment of its own, and says so rather than
        // inheriting the original transition's answer.
        relationshipAssessment: 'NOT_APPLICABLE',
        // NPL-22 — a reconciliation IS a verification, so it carries its
        // proposition. NPL-18: what the external system established.
        verificationProposition: {
          subject: String(key), expected: 'RECONCILED', observed: 'RECONCILED',
          source: 'external:reconciliation', at: this.d.time.now(),
          relation: 'DECLARED_PREDICATE', scope: 'reconcile-by-key',
        },
        outcomeClass: 'VERIFIED_SUCCESS',
      } satisfies TransitionOutcome,
    };
  };

  buildRequest(c: CameraCommand): TransitionRequest {
    return {
      transitionId: transitionId(`camdel-${c.tenantId}-${c.cameraId}`),
      requestId: requestId(`req-${c.cameraId}`),
      actor: c.actor,
      action: 'CAMERA.DELETE',
      target: { tenantId: c.tenantId, resourceType: 'camera', resourceId: c.cameraId, version: c.cameraVersion },
      purpose: c.purpose,
      intent: `permanently delete camera ${c.cameraId} and its footage`,
      expectedPostState: 'DELETED' satisfies CameraState,
      consequence: 'C4',
      reversibility: 'IRREVERSIBLE',
      policyVersion: 'neurolook-policy:v2',
      idempotencyKey: deriveCameraKey(c),
      quantities: { retentionDaysRemaining: c.retentionDaysRemaining },
      evidence: [{
        evidenceId: `ev-${c.cameraId}` as never, source: 'neurolook-registry',
        observedAt: c.evidenceObservedAt, freshnessRequirementMs: c.evidenceFreshnessMs,
      }],
      ...(c.approval ? { approval: c.approval } : {}),
    };
  }

  async execute(c: CameraCommand): Promise<TransitionOutcome> {
    const req = this.buildRequest(c);
    const effect: Effect = async (r, token) => {
      const res = await this.d.store.delete({
        idempotencyKey: String(r.idempotencyKey), cameraId: c.cameraId, fencingToken: token,
      });
      const probe = await this.d.store.probe(c.cameraId);
      // The only probe result that establishes deletion is a TOMBSTONE.
      // NOT_FOUND and UNREACHABLE are both "we cannot tell" — they become
      // UNOBSERVABLE, never DELETED.
      const observed =
        probe.kind === 'TOMBSTONE' ? 'DELETED'
          : probe.kind === 'PRESENT' ? probe.state
            : UNOBSERVABLE;
      this.d.resources.put({ ...r.target }, observed);
      return { accepted: res.accepted };
    };
    return this.d.kernel.run(req, effect);
  }
}
