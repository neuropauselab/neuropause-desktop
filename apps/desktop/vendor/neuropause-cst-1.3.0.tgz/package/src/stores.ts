/**
 * NP-CANON-1.0 §2.5 / §2.6 — the stores the kernel depends on.
 *
 * The ClaimStore is the important one. It exposes BOTH forms deliberately so
 * that the prohibited form can be demonstrated to fail, not merely asserted to.
 */
import type { FencingToken, IdempotencyKey, ResourceIdentity } from './types.js';

/** NP-CST-62 — a declared time source with a stated skew bound. */
export interface TimeSource {
  readonly id: string;
  readonly maxSkewMs: number;
  /** wall clock — approvals, expiries, evidence timestamps */
  now(): number;
  /** monotonic — durations only. NP-CST-63: never derive duration from wall clock. */
  elapsed(): number;
}

export class SystemTime implements TimeSource {
  readonly id = 'system';
  readonly maxSkewMs = 0;
  #base: number;
  #origin: number;
  constructor(fixedNow?: number) {
    this.#base = fixedNow ?? Date.now();
    this.#origin = 0;
  }
  now(): number { return this.#base; }
  advance(ms: number): void { this.#base += ms; this.#origin += ms; }
  elapsed(): number { return this.#origin; }
}

export type IntentState = 'IN_FLIGHT' | 'DONE';

export interface ClaimResult {
  readonly won: boolean;
  readonly owner: string;
  readonly fencingToken: FencingToken;
}

/** The contract a claim store must satisfy. NP-PG-10 is a statement about the
 *  STORE's guarantee, not about the kernel's control flow. */
export interface ClaimStorePort {
  claimAtomic(key: string, owner: string): ClaimResult;
  claimCheckThenAct(key: string, owner: string): Promise<ClaimResult>;
  release(key: string, owner: string): boolean;
  currentToken(key: string): number | null;
}

/** The contract an intent store must satisfy. NP-PG-09 is about DURABILITY. */
export interface IdempotencyStorePort {
  acquire(key: IdempotencyKey): { fresh: boolean; state: IntentState; outcome?: unknown };
  complete(key: IdempotencyKey, outcome: unknown): void;
  release(key: IdempotencyKey): void;
}

export class ClaimStore implements ClaimStorePort {
  #owners = new Map<string, { owner: string; token: number }>();
  #nextToken = 1;

  /**
   * NP-CST-28 — REQUIRED FORM. Read and write with no suspension point between
   * them, so at most one caller can win.
   */
  claimAtomic(key: string, owner: string): ClaimResult {
    const held = this.#owners.get(key);
    if (held) {
      return { won: false, owner: held.owner, fencingToken: held.token as FencingToken };
    }
    const token = this.#nextToken++;
    this.#owners.set(key, { owner, token });
    return { won: true, owner, fencingToken: token as FencingToken };
  }

  /**
   * NP-CST-28 — PROHIBITED FORM, retained only so the mutation suite can prove
   * the control detects it. There is an await between the check and the act;
   * two concurrent callers both pass the check.
   */
  async claimCheckThenAct(key: string, owner: string): Promise<ClaimResult> {
    const held = this.#owners.get(key);
    await Promise.resolve();           // the window
    if (held) {
      return { won: false, owner: held.owner, fencingToken: held.token as FencingToken };
    }
    const token = this.#nextToken++;
    this.#owners.set(key, { owner, token });
    return { won: true, owner, fencingToken: token as FencingToken };
  }

  /**
   * NP-CST-100 — ownership-checked release. A claim is held for the DURATION of
   * an attempt, not forever: without release, no legitimate retry of the same
   * transition can ever proceed, and a dead holder blocks the resource
   * permanently.
   */
  release(key: string, owner: string): boolean {
    const held = this.#owners.get(key);
    if (!held || held.owner !== owner) return false;
    this.#owners.delete(key);
    return true;
  }

  currentToken(key: string): number | null {
    return this.#owners.get(key)?.token ?? null;
  }
}

export class IdempotencyStore implements IdempotencyStorePort {
  #records = new Map<IdempotencyKey, { state: IntentState; outcome?: unknown }>();

  /** NP-CST-106 — the intent record is written BEFORE the external effect. */
  acquire(key: IdempotencyKey): { fresh: boolean; state: IntentState; outcome?: unknown } {
    const existing = this.#records.get(key);
    if (existing) return { fresh: false, ...existing };
    this.#records.set(key, { state: 'IN_FLIGHT' });
    return { fresh: true, state: 'IN_FLIGHT' };
  }

  /**
   * NP-CST-107 — a replay of a completed key returns the ORIGINAL outcome, so
   * the whole outcome is stored, not just its verification value. Storing only
   * the verdict produces a replay record saying `executed: false` for an intent
   * that did execute.
   */
  complete(key: IdempotencyKey, outcome: unknown): void {
    this.#records.set(key, { state: 'DONE', outcome });
  }

  /**
   * Released when the transition bails AFTER acquiring but BEFORE the effect.
   * Without this, a held key blocks the legitimate retry forever — the intent
   * record would outlive the intent.
   */
  release(key: IdempotencyKey): void {
    if (this.#records.get(key)?.state === 'IN_FLIGHT') this.#records.delete(key);
  }
}

export interface ResourceRecord {
  readonly state: unknown;
  readonly version: number;
  /**
   * NPL-23 — verification is DIRECTIONAL and subject-bound. "Customer 456 is
   * SUSPENDED" is a true observation and is not verification of "suspend
   * customer 123". An observation must carry what it is an observation OF.
   */
  readonly subject: string;
}

export class ResourceStore {
  #rows = new Map<string, ResourceRecord>();
  #fence = new Map<string, number>();

  static key(r: Pick<ResourceIdentity, 'tenantId' | 'resourceType' | 'resourceId'>): string {
    return `${r.tenantId}/${r.resourceType}/${r.resourceId}`;
  }

  put(r: ResourceIdentity, state: unknown): void {
    // NPL-23 — the record carries the SUBJECT it is a record OF. An observation
    // that cannot say what it is an observation of cannot verify anything.
    this.#rows.set(ResourceStore.key(r), {
      state, version: r.version, subject: ResourceStore.key(r),
    });
  }

  /** The authoritative read used for verification — NP-CST-39. */
  observe(r: Pick<ResourceIdentity, 'tenantId' | 'resourceType' | 'resourceId'>): ResourceRecord | null {
    return this.#rows.get(ResourceStore.key(r)) ?? null;
  }

  /**
   * NP-CST-31 — fenced conditional write. Rejects a stale lease holder and
   * rejects a version mismatch. Returns false rather than throwing: a lost
   * write is a normal outcome (NP-CST-29).
   */
  compareAndSet(
    r: Pick<ResourceIdentity, 'tenantId' | 'resourceType' | 'resourceId'>,
    expectedVersion: number,
    next: unknown,
    token: number,
  ): boolean {
    const k = ResourceStore.key(r);
    const current = this.#rows.get(k);
    if (!current || current.version !== expectedVersion) return false;
    const seen = this.#fence.get(k) ?? 0;
    if (token < seen) return false;                 // stale owner
    this.#fence.set(k, token);
    this.#rows.set(k, { state: next, version: expectedVersion + 1, subject: k });
    return true;
  }

  /**
   * NPL-23 test hook. Rewrites the SUBJECT of a stored record while leaving its
   * state intact — modelling an observer that answers correctly about the wrong
   * thing. Used only by NP-NC-25; there is no production caller.
   */
  misbindSubject(r: Pick<ResourceIdentity, 'tenantId' | 'resourceType' | 'resourceId'>,
                 wrongSubject: string): void {
    const k = ResourceStore.key(r);
    const cur = this.#rows.get(k);
    if (cur) this.#rows.set(k, { ...cur, subject: wrongSubject });
  }

  /** Mutate out-of-band, to simulate another process writing between stages. */
  driftVersion(r: Pick<ResourceIdentity, 'tenantId' | 'resourceType' | 'resourceId'>): void {
    const k = ResourceStore.key(r);
    const cur = this.#rows.get(k);
    if (cur) this.#rows.set(k, { state: cur.state, version: cur.version + 1, subject: k });
  }
}

export interface PolicyDecision {
  readonly authorized: boolean;
  readonly requiresApproval: boolean;
  /**
   * Separation of duties is a POLICY choice, not a universal rule: many systems
   * legitimately let a manager both request and approve inside their own
   * authority. It is therefore declared per action, never hard-coded — keeping
   * it distinct from the model-authority rule, which IS universal.
   */
  readonly separationOfDuties: boolean;
  /** NPC-1.0 §4 — this action's governance depends on relationship context. */
  readonly requiresRelationshipContext: boolean;
}

export class PolicyStore {
  constructor(
    private readonly grants: ReadonlyMap<string, ReadonlySet<string>>,
    readonly version: string,
    /** actions for which the requester may not also be the approver */
    private readonly sodActions: ReadonlySet<string> = new Set(),
    /**
     * NPC-1.0 §4 / NP-NC-20 — actions whose governance depends on relationship
     * context. Declared per action, never assumed universal: a read of public
     * reference data has no relationship to establish, and pretending it does
     * would make the control noise that teams learn to bypass.
     */
    private readonly relationshipActions: ReadonlySet<string> = new Set(),
    /** max age of a relationship observation, ms. 0 = no freshness requirement. */
    readonly relationshipMaxAgeMs: number = 0,
    /**
     * NPC-23 — what an UNASSESSED relationship earns is a PROFILE decision, not a
     * universal rule. A C4 deletion may DENY; a C2 update may HOLD for enrichment.
     * The STATES are constitutional; the VERDICT per state is not.
     */
    readonly relationshipUnassessedVerdict: 'DENY' | 'HOLD' = 'DENY',
  ) {}

  /** NP-CST-22 — authorization over the full tuple, never the actor alone. */
  evaluate(actorId: string, action: string, consequence: string): PolicyDecision {
    const allowed = this.grants.get(actorId)?.has(action) ?? false;
    const requiresApproval = consequence === 'C2' || consequence === 'C3' || consequence === 'C4';
    return {
      authorized: allowed, requiresApproval,
      separationOfDuties: this.sodActions.has(action),
      requiresRelationshipContext: this.relationshipActions.has(action),
    };
  }
}

export interface EvidenceRecord {
  readonly transitionId: string;
  readonly stage: string;
  readonly at: number;
  readonly detail: Readonly<Record<string, unknown>>;
}

/** NP-CST-99 — append-only. There is no update and no delete path. */
export class EvidenceStore {
  #log: EvidenceRecord[] = [];
  append(rec: EvidenceRecord): void { this.#log.push(Object.freeze(rec)); }
  forTransition(id: string): readonly EvidenceRecord[] {
    return this.#log.filter((r) => r.transitionId === id);
  }
  get size(): number { return this.#log.length; }
}
