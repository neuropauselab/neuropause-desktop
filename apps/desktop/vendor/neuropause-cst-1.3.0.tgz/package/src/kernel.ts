/**
 * NP-CANON-1.0 Part II — the Consequential State Transition kernel.
 *
 * Order is not a style choice. Each stage exists because skipping it produced a
 * recorded defect:
 *
 *   identify → govern → approval → CLAIM → revalidate → idempotency
 *            → execute → observe → verify → evidence
 */
import {
  EvidenceStore, PolicyStore, ResourceStore,
  type ClaimStorePort, type IdempotencyStorePort, type TimeSource,
} from './stores.js';
import { UNOBSERVABLE } from './types.js';
import type {
  AssessmentState, ExecutionId, FencingToken, OutcomeClass, ReasonCode,
  TransitionOutcome, TransitionRequest, Verdict, VerificationOutcome,
  VerificationProposition,
} from './types.js';

/**
 * Each guard corresponds to one negative control. Disabling one is how the
 * mutation suite proves the control detects its own removal (NP-CST-91).
 * Production MUST run with every guard on; there is no supported configuration
 * in which a guard is off.
 */
export interface Guards {
  actorAuthorized: boolean;            // NP-NC-01
  tenantIsolation: boolean;            // NP-NC-02
  approvalExpiry: boolean;             // NP-NC-03
  approvalBinding: boolean;            // NP-NC-04
  approvalScope: boolean;              // NP-NC-05
  evidenceFreshness: boolean;          // NP-NC-06
  atomicClaim: boolean;                // NP-NC-07
  idempotency: boolean;                // NP-NC-08
  preStateRevalidation: boolean;       // NP-NC-09
  postconditionVerification: boolean;  // NP-NC-10
  recoveryGoverned: boolean;           // NP-NC-11
  modelCannotSelfAuthorize: boolean;   // NP-NC-12
  reconcileUnknownReplay: boolean;     // NP-NC-13
  constraintsEnforced: boolean;        // NP-NC-14
  separationOfDuties: boolean;         // NP-NC-15
  preflightReconcile: boolean;         // NP-NC-16
  relationshipContext: boolean;        // NP-NC-20
  observationSubjectBinding: boolean;  // NP-NC-25
}

export const ALL_GUARDS: Readonly<Guards> = Object.freeze({
  actorAuthorized: true, tenantIsolation: true, approvalExpiry: true,
  approvalBinding: true, approvalScope: true, evidenceFreshness: true,
  atomicClaim: true, idempotency: true, preStateRevalidation: true,
  postconditionVerification: true, recoveryGoverned: true,
  modelCannotSelfAuthorize: true, reconcileUnknownReplay: true,
  constraintsEnforced: true, separationOfDuties: true,
  preflightReconcile: true, relationshipContext: true,
  observationSubjectBinding: true,
});

/** The injected side effect. Returns the transport-level result only. */
export type Effect = (req: TransitionRequest, token: FencingToken) => Promise<{ accepted: boolean }>;

/**
 * NP-CST-38 / NP-NC-13 — resolves a replay whose first attempt never completed.
 * ONLY the external system can say whether its effect occurred. NeuroPause MUST
 * NOT infer that an effect happened because a request was previously issued, and
 * MUST NOT infer that it did not.
 */
export type Reconciler = (
  key: TransitionRequest['idempotencyKey'],
) => Promise<{ known: true; outcome: TransitionOutcome } | { known: false }>;

export interface KernelDeps {
  readonly time: TimeSource;
  readonly policy: PolicyStore;
  readonly claims: ClaimStorePort;
  readonly idempotency: IdempotencyStorePort;
  readonly resources: ResourceStore;
  readonly evidence: EvidenceStore;
  readonly reconcile?: Reconciler;
  readonly guards?: Partial<Guards>;
}

const halt = (
  id: TransitionRequest['transitionId'], verdict: Verdict,
  reason: ReasonCode, timeline: Record<string, number>,
  relationshipAssessment: AssessmentState = 'UNASSESSED',
): TransitionOutcome => ({
  transitionId: id, verdict, reason, claimed: false, fencingToken: null,
  executed: false, executionId: null, duplicateSuppressed: false,
  observedPostState: null, verification: 'NOT_APPLICABLE', deviation: null,
  timeline: Object.freeze({ ...timeline }), relationshipAssessment,
  verificationProposition: null,
  // NPL-20 — a halted transition did not fail; nothing was established about
  // the world at all. NOT_ATTEMPTED and VERIFIED_FAILURE are different findings.
  outcomeClass: 'NOT_ATTEMPTED',
});

/**
 * NPL-17 — resolve the relationship assessment to ONE of six distinct states.
 * Returns the STATE only; what verdict each state earns is a PROFILE decision
 * (NPC-23), not a universal one. The states are constitutional; the verdicts
 * are not.
 */
const assessRelationships = (
  req: TransitionRequest, required: boolean, maxAgeMs: number, now: number,
): AssessmentState => {
  if (!required) return 'NOT_APPLICABLE';
  if (req.relationships === undefined) return 'UNASSESSED';
  if (req.relationships.length === 0) return 'ASSESSED_NONE_FOUND';
  if (maxAgeMs > 0 && req.relationships.some((r) => now - r.observedAt > maxAgeMs)) return 'STALE';
  if (req.relationships.some((r) => r.epistemicStatus === 'UNKNOWN'
      || r.epistemicStatus === 'CONTRADICTED')) return 'UNKNOWN';
  return 'ASSESSED_FOUND';
};

export class CstKernel {
  readonly #g: Guards;
  #execSeq = 0;

  constructor(private readonly d: KernelDeps) {
    this.#g = { ...ALL_GUARDS, ...(d.guards ?? {}) };
  }

  get guards(): Readonly<Guards> { return this.#g; }

  async run(req: TransitionRequest, effect: Effect): Promise<TransitionOutcome> {
    const t: Record<string, number> = { requested: this.d.time.now() };
    const log = (stage: string, detail: Record<string, unknown>) =>
      this.d.evidence.append({ transitionId: req.transitionId, stage, at: this.d.time.now(), detail });

    log('REQUESTED', { actor: req.actor.id, action: req.action, consequence: req.consequence });

    // ---- NP-CST-35: the postcondition must be declared before anything runs.
    if (req.expectedPostState === undefined) {
      return halt(req.transitionId, 'DENY', 'POSTCONDITION_UNDECLARED', t);
    }

    // ---- NP-CI-13: purpose precedes authority.
    if (!req.purpose) return halt(req.transitionId, 'DENY', 'PURPOSE_MISSING', t);

    // ---- NP-NC-11: a recovery transition is a CST. It may not skip this path.
    if (req.recoveryOf && !this.#g.recoveryGoverned) {
      // The mutation: recovery calls the effect directly.
      await effect(req, 0 as FencingToken);
      log('RECOVERY_BYPASS', { of: req.recoveryOf });
      return { ...halt(req.transitionId, 'ALLOW', 'RECOVERY_UNGOVERNED', t), executed: true };
    }

    // ---- NP-NC-02: tenant isolation.
    if (this.#g.tenantIsolation && req.actor.tenantId !== req.target.tenantId) {
      log('DENIED', { reason: 'TENANT_ISOLATION_VIOLATION' });
      return halt(req.transitionId, 'DENY', 'TENANT_ISOLATION_VIOLATION', t);
    }

    // ---- NP-NC-01: authorization over the full tuple.
    const decision = this.d.policy.evaluate(req.actor.id, req.action, req.consequence);
    if (this.#g.actorAuthorized && !decision.authorized) {
      log('DENIED', { reason: 'AUTHORIZATION_FAILURE' });
      return halt(req.transitionId, 'DENY', 'AUTHORIZATION_FAILURE', t);
    }
    // ---- NP-NC-20..23 / NPL-17. Six distinct states, never collapsed. The
    // assessment runs EVEN WHEN the profile does not require it, so the outcome
    // reports NOT_APPLICABLE rather than being silent — silence is
    // indistinguishable from UNASSESSED to whoever reads the record later.
    const relRequired = this.#g.relationshipContext && decision.requiresRelationshipContext;
    const rel = assessRelationships(
      req, relRequired, this.d.policy.relationshipMaxAgeMs, this.d.time.now());
    log('RELATIONSHIP_ASSESSMENT', { state: rel, required: relRequired });
    if (relRequired) {
      if (rel === 'UNASSESSED') {
        return halt(req.transitionId, this.d.policy.relationshipUnassessedVerdict,
          'RELATIONSHIP_CONTEXT_MISSING', t, rel);
      }
      if (rel === 'STALE') {
        return halt(req.transitionId, 'HOLD', 'RELATIONSHIP_CONTEXT_STALE', t, rel);
      }
      if (rel === 'UNKNOWN') {
        return halt(req.transitionId, 'HOLD', 'RELATIONSHIP_EPISTEMIC_INSUFFICIENT', t, rel);
      }
      // ASSESSED_NONE_FOUND and ASSESSED_FOUND both proceed. The first is an
      // ANSWER, not a gap, and treating it as one is the collapse NPL-17 forbids.
    }

    t.decided = this.d.time.now();

    // ---- NP-NC-12: model output has no authority. An AI actor may propose only.
    const aiRuleApplies = this.#g.modelCannotSelfAuthorize && req.actor.type === 'AI';
    const needsApproval = decision.requiresApproval || aiRuleApplies;
    if (needsApproval && !req.approval) {
      // The reason names the rule that ACTUALLY fired. If consequence alone
      // would have required approval, say so; do not attribute the hold to the
      // AI rule, or the AI control cannot be distinguished from the C-class one.
      const reason: ReasonCode =
        aiRuleApplies && !decision.requiresApproval ? 'MODEL_SELF_AUTHORIZATION' : 'APPROVAL_REQUIRED';
      log('HOLD', { reason });
      return halt(req.transitionId, 'HOLD', reason, t);
    }

    if (req.approval) {
      const a = req.approval;
      // ---- NP-NC-12 — the approval itself must not originate from the model,
      //      and an actor may not approve its own consequential action. Without
      //      this, a model that can construct an Approval object authorises
      //      itself, and the AI control is defeated by a data structure.
      if (this.#g.modelCannotSelfAuthorize && a.approver.type === 'AI') {
        log('BLOCKED', { reason: 'MODEL_SELF_AUTHORIZATION', approver: a.approver.id });
        return halt(req.transitionId, 'DENY', 'MODEL_SELF_AUTHORIZATION', t);
      }
      // ---- NP-NC-15 — separation of duties, WHERE THE POLICY DECLARES IT.
      //      Distinct from the rule above: that one is universal, this one is a
      //      policy choice. Collapsing them would make an unrelated product's
      //      legitimate self-approval look like a model-authority violation.
      if (this.#g.separationOfDuties && decision.separationOfDuties
          && a.approver.id === req.actor.id) {
        log('BLOCKED', { reason: 'SEPARATION_OF_DUTIES', approver: a.approver.id });
        return halt(req.transitionId, 'DENY', 'SEPARATION_OF_DUTIES', t);
      }
      // ---- NP-NC-04: bound to THIS transition.
      if (this.#g.approvalBinding && a.transitionId !== req.transitionId) {
        log('BLOCKED', { reason: 'APPROVAL_MISMATCH', approval: a.approvalId });
        return halt(req.transitionId, 'DENY', 'APPROVAL_MISMATCH', t);
      }
      // ---- NP-NC-05: scope covers the target, and the action matches.
      const scopeOk =
        a.action === req.action &&
        a.scope.tenantId === req.target.tenantId &&
        a.scope.resourceType === req.target.resourceType &&
        a.scope.resourceId === req.target.resourceId;
      if (this.#g.approvalScope && !scopeOk) {
        log('BLOCKED', { reason: 'APPROVAL_SCOPE_VIOLATION' });
        return halt(req.transitionId, 'DENY', 'APPROVAL_SCOPE_VIOLATION', t);
      }
      // ---- NP-NC-14: declared ceilings are enforced inside the gate. An
      //      approval for ₹1,000 must not authorise ₹10,00,000.
      if (this.#g.constraintsEnforced && a.constraints) {
        for (const [ck, ceiling] of Object.entries(a.constraints)) {
          if (!ck.startsWith('max')) continue;
          const qk = ck.slice(3, 4).toLowerCase() + ck.slice(4);
          const actual = req.quantities?.[qk];
          if (actual === undefined || actual > ceiling) {
            log('BLOCKED', { reason: 'CONSTRAINT_EXCEEDED', constraint: ck, ceiling, actual: actual ?? null });
            return halt(req.transitionId, 'DENY', 'CONSTRAINT_EXCEEDED', t);
          }
        }
      }
      if (a.consumed) return halt(req.transitionId, 'DENY', 'APPROVAL_CONSUMED', t);
      // ---- NP-NC-03: valid AT EXECUTION TIME. exists ≠ valid.
      if (this.#g.approvalExpiry && this.d.time.now() > a.expiresAt) {
        log('HOLD', { reason: 'APPROVAL_EXPIRED', expiredAt: a.expiresAt, now: this.d.time.now() });
        return halt(req.transitionId, 'HOLD', 'APPROVAL_EXPIRED', t);
      }
    }

    // ---- NP-NC-06: freshness is the CONSUMER's requirement, per evidence item.
    if (this.#g.evidenceFreshness) {
      const now = this.d.time.now();
      const stale = req.evidence.find((e) => now - e.observedAt > e.freshnessRequirementMs);
      if (stale) {
        log('HOLD', { reason: 'EVIDENCE_STALE', evidence: stale.evidenceId });
        return halt(req.transitionId, 'HOLD', 'EVIDENCE_STALE', t);
      }
    }

    // ---- NP-NC-07: validity is not ownership. One atomic winner, or none.
    const claimKey = `${req.transitionId}`;
    const claim = this.#g.atomicClaim
      ? this.d.claims.claimAtomic(claimKey, req.actor.id)
      : await this.d.claims.claimCheckThenAct(claimKey, req.actor.id);
    if (!claim.won) {
      log('CLAIM_LOST', { owner: claim.owner });
      return halt(req.transitionId, 'HOLD', 'CLAIM_LOST', t);
    }
    t.claimed = this.d.time.now();
    log('CLAIMED', { owner: claim.owner, fencingToken: claim.fencingToken });

    // The claim is held for the duration of THIS attempt only.
    const release = () => { this.d.claims.release(claimKey, req.actor.id); };

    // ---- NP-NC-08: replay check BEFORE revalidation. A replay of a completed
    //      intent returns the original outcome and does not re-execute
    //      (NP-CST-107); it must not be blocked by the version its own first
    //      attempt advanced.
    let duplicateSuppressed = false;
    if (this.#g.idempotency) {
      const idem = this.d.idempotency.acquire(req.idempotencyKey);
      if (!idem.fresh && idem.state === 'DONE') {
        // NP-CST-107 — the replay reports the ORIGINAL determination, but it
        // MUST NOT claim `executed: true` for itself: an auditor counting
        // executions from outcomes would then count two effects for one.
        // And a replay of an original that was UNKNOWN stays UNKNOWN — it is
        // re-reconciled, never promoted to "done" by having been seen before.
        log('IDEMPOTENT_REPLAY', { key: req.idempotencyKey, state: 'DONE' });
        const original = idem.outcome as TransitionOutcome | undefined;
        if (original && original.verification === 'UNKNOWN') {
          if (this.#g.reconcileUnknownReplay && this.d.reconcile) {
            const r = await this.d.reconcile(req.idempotencyKey);
            if (r.known && r.outcome.verification !== 'UNKNOWN') {
              this.d.idempotency.complete(req.idempotencyKey, r.outcome);
              release();
              return { ...r.outcome, executed: false, duplicateSuppressed: true };
            }
          }
          release();
          return {
            ...halt(req.transitionId, 'HOLD', 'RECONCILIATION_REQUIRED', t),
            claimed: true, fencingToken: claim.fencingToken,
            executionId: original.executionId, verification: 'UNKNOWN',
          };
        }
        release();
        if (original) return { ...original, executed: false, duplicateSuppressed: true };
        return {
          ...halt(req.transitionId, 'HOLD', 'OUTCOME_UNKNOWN', t),
          claimed: true, fencingToken: claim.fencingToken,
          verification: 'UNKNOWN',
        };
      }
      if (!idem.fresh && idem.state === 'IN_FLIGHT') {
        // NP-NC-13 — the first attempt started and never completed: crash, or a
        // lost response. Whether the external effect occurred is UNKNOWN, and
        // UNKNOWN is not "already done". It is reconciled against the external
        // system by key, or it escalates. It is never reported as a suppressed
        // duplicate, because that asserts an effect we have not observed.
        log('REPLAY_UNRESOLVED', { key: req.idempotencyKey, state: 'IN_FLIGHT' });
        if (this.#g.reconcileUnknownReplay && this.d.reconcile) {
          const r = await this.d.reconcile(req.idempotencyKey);
          // A reconciliation that comes back UNKNOWN has resolved nothing. It
          // MUST NOT be recorded as a suppressed duplicate — that would assert
          // an effect the external system declined to confirm.
          if (r.known && r.outcome.verification !== 'UNKNOWN') {
            log('RECONCILED', { key: req.idempotencyKey, verification: r.outcome.verification });
            this.d.idempotency.complete(req.idempotencyKey, r.outcome);
            release();
            return { ...r.outcome, executed: false, duplicateSuppressed: true };
          }
        }
        release();
        return {
          ...halt(req.transitionId, this.#g.reconcileUnknownReplay ? 'HOLD' : 'ALLOW',
            this.#g.reconcileUnknownReplay ? 'RECONCILIATION_REQUIRED' : 'IDEMPOTENCY_HELD', t),
          claimed: true, fencingToken: claim.fencingToken,
          duplicateSuppressed: !this.#g.reconcileUnknownReplay,
          verification: 'UNKNOWN',
        };
      }
    }

    // ---- NP-NC-16: the intent record says "never attempted". After a process
    //      restart that is indistinguishable from "record lost". Before moving
    //      money, ask the external system whether it already knows this key.
    //      Without this, restart + a rail that does not dedupe = a second real
    //      payment. Measured: 18 duplicate settlements in 400 scenarios.
    if (this.#g.preflightReconcile && this.d.reconcile) {
      const prior = await this.d.reconcile(req.idempotencyKey);
      if (prior.known) {
        log('PREFLIGHT_PRIOR_ATTEMPT', { key: req.idempotencyKey, verification: prior.outcome.verification });
        this.d.idempotency.complete(req.idempotencyKey, prior.outcome);
        release();
        return prior.outcome.verification === 'UNKNOWN'
          ? {
              ...halt(req.transitionId, 'HOLD', 'RECONCILIATION_REQUIRED', t),
              claimed: true, fencingToken: claim.fencingToken, verification: 'UNKNOWN',
            }
          : { ...prior.outcome, executed: false, duplicateSuppressed: true };
      }
    }

    // ---- NP-NC-09: critical revalidation AFTER the claim, before the effect.
    const observedBefore = this.d.resources.observe(req.target);
    if (this.#g.preStateRevalidation && observedBefore?.version !== req.target.version) {
      log('HOLD', {
        reason: 'STALE_RESOURCE_VERSION',
        expected: req.target.version, actual: observedBefore?.version ?? null,
      });
      this.d.idempotency.release(req.idempotencyKey);   // the intent never started
      release();
      return {
        ...halt(req.transitionId, 'HOLD', 'STALE_RESOURCE_VERSION', t),
        claimed: true, fencingToken: claim.fencingToken,
      };
    }

    // ---- the only irreversible link.
    const execId = `exec-${++this.#execSeq}` as ExecutionId;
    t.executionStarted = this.d.time.now();
    let res: { accepted: boolean };
    try {
      res = await effect(req, claim.fencingToken);
    } catch (e) {
      // NP-CST-38 — an exception is NOT a determination that nothing happened.
      // The intent record stays IN_FLIGHT so the retry reconciles rather than
      // re-executes, the claim is released so the retry can proceed, and the
      // caller receives a governed outcome instead of a bare throw.
      t.executionCompleted = this.d.time.now();
      log('EXECUTION_ERROR', { executionId: execId, error: (e as Error).message });
      release();
      return {
        ...halt(req.transitionId, 'HOLD', 'OUTCOME_UNKNOWN', t),
        claimed: true, fencingToken: claim.fencingToken,
        executed: false, executionId: execId, verification: 'UNKNOWN',
      };
    }
    t.executionCompleted = this.d.time.now();
    log('EXECUTED', { executionId: execId, accepted: res.accepted });

    // ---- NP-NC-10: the response is not the outcome. Observe authoritatively.
    const observedAfter = this.d.resources.observe(req.target);
    const observedPostState = observedAfter?.state ?? null;
    let verification: VerificationOutcome;
    // NPL-23 — verification is DIRECTIONAL and subject-bound. An observation of
    // ANOTHER subject can be perfectly true and still verify nothing here.
    const wantSubject = ResourceStore.key(req.target);
    const subjectMismatch = this.#g.observationSubjectBinding
      && observedAfter !== null && observedAfter.subject !== wantSubject;

    if (!this.#g.postconditionVerification) {
      // The mutation: map transport success straight to VERIFIED.
      verification = res.accepted ? 'VERIFIED' : 'DEVIATION';
    } else if (subjectMismatch) {
      // We read SOMETHING. It was not about our target. That establishes
      // nothing about this transition — UNKNOWN, never DEVIATION and never
      // VERIFIED. This is the "customer 456 is SUSPENDED" failure.
      verification = 'UNKNOWN';
    } else if (observedAfter === null || observedPostState === UNOBSERVABLE) {
      // The authoritative source declined to answer. That is UNKNOWN, never
      // DEVIATION: a deviation asserts the state DIFFERS, which is a claim we
      // have no evidence for.
      verification = 'UNKNOWN';
    } else {
      verification =
        JSON.stringify(observedPostState) === JSON.stringify(req.expectedPostState)
          ? 'VERIFIED' : 'DEVIATION';
    }
    t.verified = this.d.time.now();

    // NPL-22 — the proposition the verdict is a verdict ABOUT. Built here so
    // that no code path can emit VERIFIED without one.
    const proposition: VerificationProposition = {
      subject: observedAfter?.subject ?? wantSubject,
      expected: req.expectedPostState,
      observed: observedPostState,
      source: 'resource-store:authoritative',
      at: t.verified,
      relation: 'STRUCTURAL_EQUALITY',
      scope: `${req.action}@${req.policyVersion}`,
    };

    // NPL-18..21 — four outcome classes. VERIFIED_FAILURE is a POSITIVE finding
    // and is reserved for a rail/effect that reported non-acceptance AND whose
    // post-state confirms the intended effect did not occur. UNKNOWN is what we
    // report when nothing was established.
    const outcomeClass: OutcomeClass =
      verification === 'VERIFIED' ? 'VERIFIED_SUCCESS'
      : verification === 'UNKNOWN' ? 'UNKNOWN'
      : !res.accepted ? 'VERIFIED_FAILURE'
      : 'DEVIATION';

    log('VERIFICATION', {
      verification, outcomeClass, subjectMismatch,
      expected: req.expectedPostState, observed: observedPostState,
      observedSubject: proposition.subject, wantSubject,
    });

    const outcome: TransitionOutcome = {
      relationshipAssessment: rel,
      transitionId: req.transitionId,
      verdict: 'ALLOW',
      reason: 'OK',
      claimed: true,
      fencingToken: claim.fencingToken,
      executed: true,
      executionId: execId,
      duplicateSuppressed,
      observedPostState,
      verification,
      deviation: verification === 'DEVIATION'
        ? { expected: req.expectedPostState, observed: observedPostState } : null,
      timeline: Object.freeze({ ...t }),
      verificationProposition: proposition,
      outcomeClass,
    };
    this.d.idempotency.complete(req.idempotencyKey, outcome);
    release();
    return outcome;
  }
}
