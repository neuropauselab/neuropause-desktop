/**
 * PH-8.14 — the hostile rail.
 *
 * `FakeRail` was written by the same author as the controls, so it can only fail
 * in ways that author imagined. That is a closed loop, and a closed loop cannot
 * establish that a simulation is correct.
 *
 * This rail is written to be adversarial instead: it loses responses in both
 * directions, settles late, reverses after settling, delivers duplicates,
 * returns a wrong reference, and — in one mode — does NOT deduplicate by
 * idempotency key at all. Real rails do all of these.
 */
import type { PaymentProvider, PaymentState } from '../src/payment.js';

/** Seeded xorshift32 — D-SEEDED under MSD-152. The seed is part of the record. */
export class Rng {
  #s: number;
  constructor(seed: number) { this.#s = seed || 0x9e3779b9; }
  next(): number {
    let x = this.#s;
    x ^= x << 13; x >>>= 0;
    x ^= x >> 17;
    x ^= x << 5; x >>>= 0;
    this.#s = x;
    return x / 0x1_0000_0000;
  }
  int(n: number): number { return Math.floor(this.next() * n); }
  chance(p: number): boolean { return this.next() < p; }
  pick<T>(xs: readonly T[]): T { return xs[this.int(xs.length)]!; }
}

export interface RailBehaviour {
  /** the rail does NOT dedupe by idempotency key — a real hazard */
  nonIdempotent: boolean;
  /** submit performs the effect, then the response is lost */
  loseResponsePr: number;
  /** submit is rejected outright before any effect */
  rejectPr: number;
  /** the payment stalls in SUBMITTED instead of settling */
  stallPr: number;
  /** the payment settles, then is reversed by the rail */
  reversePr: number;
  /** statusOf returns UNKNOWN even though the attempt exists */
  statusBlindPr: number;
}

export interface RailLedgerEntry {
  key: string;
  ref: string;
  state: PaymentState;
  amountMinor: number;
  submittedAt: number;
}

export class HostileRail implements PaymentProvider {
  readonly submissions: { key: string; amountMinor: number }[] = [];
  readonly ledger: RailLedgerEntry[] = [];
  #seq = 0;

  constructor(
    private readonly rng: Rng,
    private readonly b: RailBehaviour,
    private readonly clock: () => number,
  ) {}

  /** Every distinct movement of money the rail believes it performed. */
  get settledEntries(): readonly RailLedgerEntry[] {
    return this.ledger.filter((e) => e.state === 'SETTLED');
  }

  settledCountFor(key: string): number {
    return this.ledger.filter((e) => e.key === key && e.state === 'SETTLED').length;
  }

  totalDebitedMinor(): number {
    return this.ledger
      .filter((e) => e.state === 'SETTLED' || e.state === 'SUBMITTED')
      .reduce((s, e) => s + e.amountMinor, 0);
  }

  async submit(cmd: { idempotencyKey: string; amountMinor: number; fencingToken: number }) {
    this.submissions.push({ key: cmd.idempotencyKey, amountMinor: cmd.amountMinor });

    if (!this.b.nonIdempotent) {
      const existing = this.ledger.find((e) => e.key === cmd.idempotencyKey);
      if (existing) {
        if (this.rng.chance(this.b.loseResponsePr)) throw new Error('rail: response lost on replay');
        return { accepted: true, providerRef: existing.ref };
      }
    }

    if (this.rng.chance(this.b.rejectPr)) return { accepted: false };

    const ref = `pref-${++this.#seq}`;
    let state: PaymentState = this.rng.chance(this.b.stallPr) ? 'SUBMITTED' : 'SETTLED';
    this.ledger.push({
      key: cmd.idempotencyKey, ref, state,
      amountMinor: cmd.amountMinor, submittedAt: this.clock(),
    });
    if (state === 'SETTLED' && this.rng.chance(this.b.reversePr)) {
      const row = this.ledger[this.ledger.length - 1]!;
      row.state = 'FAILED';                       // reversed by the rail after settling
      state = 'FAILED';
    }
    // the effect has ALREADY happened at this point
    if (this.rng.chance(this.b.loseResponsePr)) throw new Error('rail: response lost after effect');
    return { accepted: true, providerRef: ref };
  }

  async statusOf(ref: string): Promise<PaymentState | 'UNKNOWN'> {
    if (this.rng.chance(this.b.statusBlindPr)) return 'UNKNOWN';
    return this.ledger.find((e) => e.ref === ref)?.state ?? 'UNKNOWN';
  }

  async lookupByKey(key: string) {
    if (this.rng.chance(this.b.statusBlindPr)) return { found: false };
    const hit = this.ledger.find((e) => e.key === key);
    return hit ? { found: true, providerRef: hit.ref } : { found: false };
  }
}
