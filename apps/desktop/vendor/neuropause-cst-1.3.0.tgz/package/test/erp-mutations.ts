/**
 * PH-8.13 — mutation suite for the ERP payment controls.
 * Each guard is removed and its control MUST then fail.
 */
import { PAY_CONTROLS, MUTATION } from './erp-payment.js';
import type { Guards } from '../src/kernel.js';

const GUARD_FOR: Readonly<Record<string, keyof Guards>> = {
  'NP-NC-01': 'actorAuthorized',
  'NP-NC-02': 'tenantIsolation',
  'NP-NC-03': 'approvalExpiry',
  'NP-NC-04': 'approvalBinding',
  'NP-NC-05': 'approvalScope',
  'NP-NC-06': 'evidenceFreshness',
  'NP-NC-07': 'atomicClaim',
  'NP-NC-08': 'idempotency',
  'NP-NC-09': 'preStateRevalidation',
  'NP-NC-10': 'postconditionVerification',
  'NP-NC-11': 'recoveryGoverned',
  'NP-NC-12': 'modelCannotSelfAuthorize',
  'NP-NC-13': 'reconcileUnknownReplay',
  'NP-NC-14': 'constraintsEnforced',
  'NP-NC-15': 'separationOfDuties',
  'NP-NC-16': 'preflightReconcile',
};

console.log('\nPH-8.13 MUTATION SUITE — ERP PAYMENT\n' + '='.repeat(76));
let proven = 0, mapped = 0;
for (const c of PAY_CONTROLS) {
  const guard = GUARD_FOR[c.id];
  if (!guard) { console.log(`${c.id.padEnd(10)} NO GUARD MAPPED`); continue; }
  mapped++;
  MUTATION.disabled = guard;
  let stillPasses: boolean;
  try { stillPasses = (await c.run()) === null; } catch { stillPasses = false; }
  MUTATION.disabled = null;
  if (!stillPasses) proven++;
  console.log(`${c.id.padEnd(10)} ${(stillPasses ? 'NOT PROVEN' : 'DETECTED').padEnd(12)}guard removed: ${guard}`);
}
console.log('='.repeat(76));
console.log(`controls with a proven detection: ${proven}/${mapped}`);
console.log('DETECTION COMPLETENESS: NOT ESTABLISHED — declared guard-removal class only,');
console.log('against the FakeRail boundary, in this environment.');
process.exit(proven === mapped ? 0 : 1);
