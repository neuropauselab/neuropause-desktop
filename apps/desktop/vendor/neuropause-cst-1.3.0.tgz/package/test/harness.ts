/** Minimal harness — no test framework, so this runs anywhere Node runs. */
export interface Case { id: string; name: string; run: () => Promise<string | null>; }
export async function runAll(title: string, cases: readonly Case[]): Promise<number> {
  console.log(`\n${title}\n${'='.repeat(76)}`);
  let failed = 0;
  for (const c of cases) {
    let err: string | null;
    try { err = await c.run(); } catch (e) { err = `threw: ${(e as Error).message}`; }
    if (err) failed++;
    console.log(`${c.id.padEnd(10)} ${(err ? 'FAIL' : 'PASS').padEnd(5)} ${c.name}${err ? `  — ${err}` : ''}`);
  }
  console.log('='.repeat(76));
  console.log(`${cases.length - failed}/${cases.length} passed`);
  return failed;
}
export const eq = (actual: unknown, expected: unknown, what: string): string | null =>
  actual === expected ? null : `${what}: expected ${String(expected)}, got ${String(actual)}`;
