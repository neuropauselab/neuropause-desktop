/**
 * NP-CST-92 — the reference certification fixture.
 *
 *   tenant-A / customer / 123 / v17, state ACTIVE
 *   an AI proposes SUSPEND for a fraud-risk purpose
 *   the AI may propose and may not execute
 *   a human approval, bound to the transition, scoped, with an expiry
 *   two workers race for the claim
 *   the pre-state version is revalidated after the claim
 *   the post-state is read from the authoritative source, not from the response
 */
import {
  ClaimStore, EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime,
} from '../src/stores.js';
import { CstKernel, type Effect, type Guards } from '../src/kernel.js';
import {
  approvalId, idempotencyKey, requestId, transitionId,
  type Approval, type Actor, type ResourceIdentity, type TransitionRequest,
} from '../src/types.js';

export const T0 = 1_760_000_000_000;

export const AI: Actor = { id: 'agent-1', type: 'AI', tenantId: 'tenant-A' };
export const OPERATOR: Actor = { id: 'op-1', type: 'HUMAN', tenantId: 'tenant-A' };
export const OUTSIDER: Actor = { id: 'op-9', type: 'HUMAN', tenantId: 'tenant-B' };
export const UNGRANTED: Actor = { id: 'op-x', type: 'HUMAN', tenantId: 'tenant-A' };

export const TARGET: ResourceIdentity = {
  tenantId: 'tenant-A', resourceType: 'customer', resourceId: '123', version: 17,
};

export interface Rig {
  time: SystemTime;
  resources: ResourceStore;
  claims: ClaimStore;
  idem: IdempotencyStore;
  evidence: EvidenceStore;
  kernel: CstKernel;
  /** honours the fencing token and the expected version — a real conditional write */
  effect: Effect;
  /** accepts the command and changes nothing — the HTTP 200 that lies */
  noopEffect: Effect;
}

/** Set by the mutation suite; null in normal runs. See test/mutations.ts. */
export const MUTATION: { disabled: keyof Guards | null } = { disabled: null };

export interface PolicyOverrides {
  /** NPC-23 — which actions are relationship-governed, per PROFILE. */
  relationshipActions?: ReadonlySet<string>;
  relationshipMaxAgeMs?: number;
  relationshipUnassessedVerdict?: 'DENY' | 'HOLD';
}

export function rig(guards: Partial<Guards> = {}, pol: PolicyOverrides = {}): Rig {
  const applied: Partial<Guards> = { ...guards };
  if (MUTATION.disabled) applied[MUTATION.disabled] = false;
  const time = new SystemTime(T0);
  const resources = new ResourceStore();
  resources.put(TARGET, 'ACTIVE');
  const claims = new ClaimStore();
  const idem = new IdempotencyStore();
  const evidence = new EvidenceStore();
  const policy = new PolicyStore(
    new Map([
      ['agent-1', new Set(['SUSPEND'])],
      ['op-1', new Set(['SUSPEND'])],
      ['op-9', new Set(['SUSPEND'])],
    ]),
    'policy:v4',
    new Set(),                                              // SoD: none for SUSPEND
    pol.relationshipActions ?? new Set(['SUSPEND']),        // NPC-23, per profile
    pol.relationshipMaxAgeMs ?? 3_600_000,                  // 1h freshness
    pol.relationshipUnassessedVerdict ?? 'DENY',            // profile decision
  );
  const kernel = new CstKernel({ time, policy, claims, idempotency: idem, resources, evidence, guards: applied });

  const effect: Effect = async (req, token) => {
    const ok = resources.compareAndSet(req.target, req.target.version, req.expectedPostState, token);
    return { accepted: ok };
  };
  const noopEffect: Effect = async () => ({ accepted: true });

  return { time, resources, claims, idem, evidence, kernel, effect, noopEffect };
}

type Over<T> = { [K in keyof T]?: T[K] | undefined };

export function approval(over: Over<Approval> = {}): Approval {
  return {
    approvalId: approvalId('A1'),
    transitionId: transitionId('T1'),
    approver: OPERATOR,
    action: 'SUSPEND',
    scope: { tenantId: 'tenant-A', resourceType: 'customer', resourceId: '123' },
    resourceVersion: 17,
    purpose: 'fraud-risk response',
    policyVersion: 'policy:v4',
    issuedAt: T0,
    expiresAt: T0 + 600_000,          // ten minutes
    consumed: false,
    ...over,
  } as Approval;
}

export function request(over: Over<TransitionRequest> = {}): TransitionRequest {
  return {
    transitionId: transitionId('T1'),
    requestId: requestId('R1'),
    actor: OPERATOR,
    action: 'SUSPEND',
    target: TARGET,
    purpose: 'fraud-risk response',
    intent: 'suspend customer 123 pending review',
    expectedPostState: 'SUSPENDED',
    consequence: 'C2',
    reversibility: 'REVERSIBLE',
    policyVersion: 'policy:v4',
    idempotencyKey: idempotencyKey('I1'),
    evidence: [{
      evidenceId: 'E1' as never, source: 'fraud-engine',
      observedAt: T0, freshnessRequirementMs: 60_000,
    }],
    approval: approval(),
    relationships: [{
      kind: 'account-owner', subject: 'party-77', object: 'customer:123',
      source: 'crm', observedAt: T0,
    }],
    ...over,
  } as TransitionRequest;
}
