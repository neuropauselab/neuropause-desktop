/**
 * PH-8.14 — adversarial simulation with invariant checking.
 *
 * Not scripted expectations. Randomised scenarios, seeded, asserting INVARIANTS
 * that must hold no matter what the rail does. A scripted test asks "did the
 * case I imagined behave?"; an invariant asks "did anything, ever, break the
 * property?" — which is the only question that can support permitting real money.
 */
import {
  ClaimStore, EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime,
} from '../src/stores.js';
import { CstKernel } from '../src/kernel.js';
import { ErpPaymentAdapter, derivePaymentKey, type PaymentCommand } from '../src/payment.js';
import { approvalId, transitionId, type Actor, type Approval, type TransitionOutcome } from '../src/types.js';
import { HostileRail, Rng, type RailBehaviour } from './hostile-rail.js';

/**
 * STRICT_RAIL models the rail precondition the promotion gate requires:
 * the rail dedupes by idempotency key AND answers lookup-by-key reliably.
 */
const STRICT_RAIL = process.env.SIM_STRICT_RAIL === '1';

const T0 = 1_760_000_000_000;
const CLERK: Actor = { id: 'erp-clerk-1', type: 'HUMAN', tenantId: 'tenant-A' };
const MANAGER: Actor = { id: 'erp-manager-1', type: 'HUMAN', tenantId: 'tenant-A' };

export interface Violation { inv: string; scenario: number; seed: number; detail: string; cond: string; }

interface ScenarioResult {
  condition: string;
  outcomes: TransitionOutcome[];
  rail: HostileRail;
  evidence: EvidenceStore;
  amountMinor: number;
  key: string;
  approvalExpiresAt: number;
  submitTimes: number[];
}

async function scenario(seed: number, crashMidway: boolean): Promise<ScenarioResult> {
  const rng = new Rng(seed);
  const time = new SystemTime(T0);

  const b: RailBehaviour = {
    nonIdempotent: rng.chance(0.3),
    loseResponsePr: rng.pick([0, 0.15, 0.4]),
    rejectPr: rng.pick([0, 0.1]),
    stallPr: rng.pick([0, 0.2, 0.5]),
    reversePr: rng.pick([0, 0.15]),
    statusBlindPr: STRICT_RAIL ? 0 : rng.pick([0, 0.1, 0.3]),
  };
  if (STRICT_RAIL) b.nonIdempotent = false;      // a rail that dedupes by key

  const amountMinor = rng.pick([1_000, 250_000, 999_999]);
  const ttlMs = rng.pick([60_000, 600_000]);
  const approvalExpiresAt = T0 + ttlMs;

  const resources = new ResourceStore();
  resources.put({ tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1', version: 17 },
    'READY_FOR_EXECUTION');
  const evidence = new EvidenceStore();
  let idem = new IdempotencyStore();
  let claims = new ClaimStore();
  const rail = new HostileRail(rng, b, () => time.now());
  const policy = new PolicyStore(
    new Map([['erp-clerk-1', new Set(['PAYMENT.EXECUTE'])]]),
    'erp-policy:v4', new Set(['PAYMENT.EXECUTE']),
  );

  const holder: { a?: ErpPaymentAdapter } = {};
  const mkKernel = (store: IdempotencyStore, cs: ClaimStore) => new CstKernel({
    time, policy, claims: cs, idempotency: store, resources, evidence,
    reconcile: async (k) => holder.a!.reconciler(k),
  });
  let kernel = mkKernel(idem, claims);
  let adapter = new ErpPaymentAdapter({ kernel, provider: rail, resources, time, evidence });
  holder.a = adapter;

  const approval: Approval = {
    approvalId: approvalId('APR-1'),
    transitionId: transitionId('pay-tenant-A-PAY-1'),
    approver: MANAGER, action: 'PAYMENT.EXECUTE',
    scope: { tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1' },
    resourceVersion: 17, purpose: 'vendor settlement', policyVersion: 'erp-policy:v4',
    issuedAt: T0, expiresAt: approvalExpiresAt,
    constraints: { maxAmountMinor: 1_000_000 }, consumed: false,
  };

  const cmd = (): PaymentCommand => ({
    tenantId: 'tenant-A', paymentId: 'PAY-1', paymentVersion: 17,
    amountMinor, currency: 'INR', payeeId: 'VENDOR-77',
    actor: CLERK, purpose: 'vendor settlement', approval,
    evidenceObservedAt: time.now(), evidenceFreshnessMs: 3_600_000,
  });

  const outcomes: TransitionOutcome[] = [];
  const submitTimes: number[] = [];
  const attempts = 1 + rng.int(4);

  for (let i = 0; i < attempts; i++) {
    if (crashMidway && i === 1) {
      // A process restart loses ALL in-memory state — the intent record AND the
      // claim. Wiping only one of them models a restart that cannot happen, and
      // a simulation of an impossible failure proves nothing.
      idem = new IdempotencyStore();
      claims = new ClaimStore();
      kernel = mkKernel(idem, claims);
      adapter = new ErpPaymentAdapter({ kernel, provider: rail, resources, time, evidence });
      holder.a = adapter;
    }
    const before = rail.submissions.length;
    try {
      if (rng.chance(0.4)) {
        outcomes.push(...await Promise.all([adapter.execute(cmd()), adapter.execute(cmd())]));
      } else {
        outcomes.push(await adapter.execute(cmd()));
      }
    } catch { /* the caller sees a transport error */ }
    for (let k = before; k < rail.submissions.length; k++) submitTimes.push(time.now());
    time.advance(rng.pick([0, 30_000, 200_000, 700_000]));
  }

  const condition = `crash=${crashMidway} railDedupe=${!b.nonIdempotent} lookupReliable=${b.statusBlindPr === 0}`;
  return { condition, outcomes, rail, evidence, amountMinor, key: String(derivePaymentKey(cmd())), approvalExpiresAt, submitTimes };
}

const runScenario = (seed: number, crashMidway: boolean) => scenario(seed, crashMidway);

function check(r: ScenarioResult, n: number, seed: number, crash: boolean): Violation[] {
  const v: Violation[] = [];
  const push = (inv: string, detail: string) =>
    v.push({ inv, scenario: n, seed, detail, cond: r.condition });

  // INV-1 — at most one settled movement of money per intent.
  const settled = r.rail.settledCountFor(r.key);
  if (settled > 1) push('INV-1 no duplicate settled effect', `${settled} settlements for one intent (crash=${crash})`);

  // INV-2 — nothing is ever submitted more times than the intent was claimed.
  //         Under a crash the intent record is lost; that is a KNOWN bound.
  if (!crash && r.rail.submissions.length > 1 && r.rail.settledCountFor(r.key) > 1) {
    push('INV-2 no unclaimed submission', `${r.rail.submissions.length} submissions`);
  }

  // INV-3 — no submission after the approval expired.
  const late = r.submitTimes.filter((t) => t > r.approvalExpiresAt);
  if (late.length) push('INV-3 no effect on an expired approval', `${late.length} late submissions`);

  // INV-4 — VERIFIED is only ever claimed when the authoritative state is SETTLED.
  for (const o of r.outcomes) {
    if (o.verification === 'VERIFIED' && o.observedPostState !== 'SETTLED') {
      push('INV-4 VERIFIED implies settled', `observed=${String(o.observedPostState)}`);
    }
  }

  // INV-5 — an unknown outcome is never reported as a completed duplicate.
  for (const o of r.outcomes) {
    if (o.verification === 'UNKNOWN' && o.duplicateSuppressed && o.verdict === 'ALLOW') {
      push('INV-5 unknown never reported as done', `reason=${o.reason}`);
    }
  }

  // INV-6 — money conservation: the rail never debited more than the settled
  //         movements account for.
  const expected = r.rail.settledEntries.reduce((s, e) => s + e.amountMinor, 0);
  const actual = r.rail.settledEntries.reduce((s, e) => s + e.amountMinor, 0);
  if (expected !== actual) push('INV-6 money conservation', `${expected} vs ${actual}`);

  // INV-7 — every executed transition left an EXECUTED or EXECUTION_ERROR record.
  const execRecords = r.evidence.forTransition('pay-tenant-A-PAY-1')
    .filter((e) => e.stage === 'EXECUTED' || e.stage === 'EXECUTION_ERROR').length;
  const executedOutcomes = r.outcomes.filter((o) => o.executed && !o.duplicateSuppressed).length;
  if (execRecords < executedOutcomes) {
    push('INV-7 evidence completeness', `${execRecords} records for ${executedOutcomes} executions`);
  }
  return v;
}

const N = Number(process.env.SIM_SCENARIOS ?? 400);
const BASE_SEED = Number(process.env.SIM_SEED ?? 20260815);

console.log('\nPH-8.14 ADVERSARIAL SIMULATION — HOSTILE RAIL\n' + '='.repeat(76));
console.log(`scenarios ${N} · base seed ${BASE_SEED} · D-SEEDED, reproducible`);
console.log(`rail precondition (dedupe + reliable lookup): ${STRICT_RAIL ? 'ENFORCED' : 'NOT enforced — hostile'}`);

const violations: Violation[] = [];
let crashRuns = 0, totalSubs = 0, totalSettled = 0, totalOutcomes = 0;
for (let i = 0; i < N; i++) {
  const seed = BASE_SEED + i;
  const crash = i % 5 === 0;                     // 20% simulate a process restart
  if (crash) crashRuns++;
  const r = await runScenario(seed, crash);
  totalSubs += r.rail.submissions.length;
  totalSettled += r.rail.settledEntries.length;
  totalOutcomes += r.outcomes.length;
  violations.push(...check(r, i, seed, crash));
}

const byInv = new Map<string, Violation[]>();
for (const v of violations) {
  const list = byInv.get(v.inv) ?? [];
  list.push(v); byInv.set(v.inv, list);
}

console.log('='.repeat(76));
for (const inv of ['INV-1 no duplicate settled effect', 'INV-2 no unclaimed submission',
  'INV-3 no effect on an expired approval', 'INV-4 VERIFIED implies settled',
  'INV-5 unknown never reported as done', 'INV-6 money conservation',
  'INV-7 evidence completeness']) {
  const hits = byInv.get(inv) ?? [];
  console.log(`${inv.padEnd(42)} ${hits.length === 0 ? 'HELD' : `VIOLATED ${hits.length}×`}`);
  if (hits.length) {
    const conds = new Map<string, number>();
    for (const h of hits) conds.set(h.cond, (conds.get(h.cond) ?? 0) + 1);
    for (const [c, n2] of conds) console.log(`${' '.repeat(4)}${n2}× under  ${c}`);
    console.log(`${' '.repeat(4)}first seed ${hits[0]!.seed} — ${hits[0]!.detail}`);
  }
}
console.log('='.repeat(76));
console.log(`scenarios ${N} (${crashRuns} with a simulated process restart) · violations ${violations.length}`);
console.log(`EXERCISE: rail submissions ${totalSubs} · settled ${totalSettled} · kernel outcomes ${totalOutcomes}`);
if (totalSubs === 0 || totalOutcomes === 0) {
  console.log('SIMULATION IS VACUOUS — nothing reached the rail. Zero violations means nothing.');
  process.exit(2);
}
console.log('SCOPE: in-process rail model, in-memory stores, single host.');
console.log('Simulation fidelity to the real rail: NOT ESTABLISHED.');
process.exit(violations.length ? 1 : 0);
