/**
 * NP-PG-10 — cross-process exclusivity, with REAL OS processes.
 *
 * The matrix could not discriminate P10 because a single-threaded in-process Map
 * is already exclusive. This test removes that excuse: N separate node processes,
 * one shared SQLite file, one shared transition key, and a SIGKILL delivered to
 * the holder while it holds the claim.
 */
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DurableStore } from '../dist/src/durable.js';

const dir = mkdtempSync(join(tmpdir(), 'np-mp-'));
const db = join(dir, 'cst.db');
new DurableStore(db).close();                       // create the schema once

const runWorker = (id, mode) => new Promise((res) => {
  const p = spawn(process.execPath, ['--no-warnings', 'test/worker.mjs', db, id, mode],
    { cwd: process.cwd() });
  let out = '';
  p.stdout.on('data', (d) => { out += d; });
  p.on('exit', (code, sig) => res({ id, out: out.trim(), code, sig, pid: p.pid }));
  p.on('error', () => res({ id, out: '', code: -1, sig: null, pid: p.pid }));
  if (mode === 'hang') setTimeout(() => res({ id, out: out.trim(), code: null, sig: 'held', proc: p, pid: p.pid }), 600);
});

const line = '='.repeat(76);
console.log(`\nNP-PG-10 CROSS-PROCESS EXCLUSIVITY — REAL PROCESSES\n${line}`);

// ---- Test 1: N processes race for one claim
const N = 8;
const results = await Promise.all(Array.from({ length: N }, (_, i) => runWorker(`w${i}`, 'race')));
const parsed = results.map((r) => { try { return JSON.parse(r.out); } catch { return { won: false, bad: r.out }; } });
const winners = parsed.filter((p) => p.won);
const tokens = new Set(parsed.map((p) => p.token));
console.log(`T1 ${N} OS processes race for one key`);
console.log(`   winners: ${winners.length}   ${winners.length === 1 ? 'PASS' : 'FAIL'}`);
console.log(`   distinct fencing tokens observed: ${tokens.size}`);
let failures = winners.length === 1 ? 0 : 1;

// ---- Test 2: the holder is SIGKILLed while holding the claim
const s = new DurableStore(db);
s.release('T-shared', winners[0]?.workerId ?? 'w0');
const held = await runWorker('victim', 'hang');
const holder = s.holderOf('T-shared');
console.log(`\nT2 holder SIGKILLed while holding the claim`);
console.log(`   claim held by: ${holder?.owner ?? 'none'} (token ${holder?.token ?? '-'})`);
held.proc?.kill('SIGKILL');
await new Promise((r) => setTimeout(r, 300));

const after = s.holderOf('T-shared');
const stillHeld = after?.owner === 'victim';
console.log(`   after SIGKILL, claim still held: ${stillHeld ? 'YES' : 'no'}`);

// a fresh worker cannot claim — the dead process's row is still there
const blocked = s.claimAtomic('T-shared', 'successor');
console.log(`   successor claim without a lease: ${blocked.won ? 'WON (defect)' : 'BLOCKED'}`);
if (blocked.won) failures++;

// ---- Test 3: lease-bounded takeover recovers it, with a NEW fencing token
const before = after?.token ?? 0;
const takeover = s.takeoverIfExpired('T-shared', 'successor', Date.now() + 60_000, 30_000);
console.log(`\nT3 lease-bounded takeover after the lease expires`);
console.log(`   takeover: ${takeover?.won ? 'WON' : 'refused'}   old token ${before} -> new token ${takeover?.fencingToken ?? '-'}`);
const fencingAdvanced = !!takeover?.won && Number(takeover.fencingToken) > Number(before);
console.log(`   fencing token advanced: ${fencingAdvanced ? 'YES' : 'NO'}  ${fencingAdvanced ? 'PASS' : 'FAIL'}`);
if (!fencingAdvanced) failures++;

// ---- Test 4: takeover is refused while the lease is live
const live = s.takeoverIfExpired('T-shared', 'thief', Date.now(), 30_000);
console.log(`\nT4 takeover attempted while the lease is LIVE`);
console.log(`   result: ${live ? 'WON (defect)' : 'refused'}  ${live ? 'FAIL' : 'PASS'}`);
if (live) failures++;

s.close();
rmSync(dir, { recursive: true, force: true });
console.log(line);
console.log(failures === 0 ? 'ALL PASS' : `${failures} FAILING`);
console.log('SCOPE: one host, one SQLite file. Multi-HOST exclusivity: NOT ESTABLISHED.');
process.exit(failures ? 1 : 0);
