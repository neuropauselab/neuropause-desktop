/**
 * NPMS-1.2 Book IV — the negative controls, executable.
 *
 * Each asserts that the system REFUSES. A suite of happy-path tests proves the
 * feature works; only these prove the governance works.
 */
import { runAll, eq, type Case } from './harness.js';
import { rig, request, approval, AI, OUTSIDER, UNGRANTED, TARGET, T0 } from './fixture.js';
import { transitionId, idempotencyKey } from '../src/types.js';

export const CONTROLS: readonly Case[] = [
  {
    id: 'NP-NC-01', name: 'unauthorized actor is denied',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({ actor: UNGRANTED, approval: undefined, consequence: 'C1' }), r.effect);
      return eq(o.reason, 'AUTHORIZATION_FAILURE', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-02', name: 'foreign tenant cannot touch this resource',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({ actor: OUTSIDER }), r.effect);
      return eq(o.reason, 'TENANT_ISOLATION_VIOLATION', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-03', name: 'approval past expiry at execution time does not execute',
    run: async () => {
      const r = rig();
      r.time.advance(700_000);              // ten-minute approval, eleven minutes later
      const o = await r.kernel.run(request(), r.effect);
      return eq(o.reason, 'APPROVAL_EXPIRED', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-04', name: 'approval issued for a different transition is rejected',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({ approval: approval({ transitionId: transitionId('T-OTHER') }) }), r.effect);
      return eq(o.reason, 'APPROVAL_MISMATCH', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-05', name: 'approval scoped to another resource is rejected',
    run: async () => {
      const r = rig();
      const scoped = approval({ scope: { tenantId: 'tenant-A', resourceType: 'customer', resourceId: '999' } });
      const o = await r.kernel.run(request({ approval: scoped }), r.effect);
      return eq(o.reason, 'APPROVAL_SCOPE_VIOLATION', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-06', name: 'evidence older than the consumer requirement holds the transition',
    run: async () => {
      const r = rig();
      r.time.advance(90_000);               // 60s freshness requirement, 90s old
      const o = await r.kernel.run(request({ approval: approval({ expiresAt: T0 + 600_000 }) }), r.effect);
      return eq(o.reason, 'EVIDENCE_STALE', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-07', name: 'two concurrent workers: exactly one claim, exactly one effect',
    run: async () => {
      const r = rig();
      let effects = 0;
      const counting = async (req: Parameters<typeof r.effect>[0], tok: Parameters<typeof r.effect>[1]) => {
        effects++; return r.effect(req, tok);
      };
      const [a, b] = await Promise.all([
        r.kernel.run(request(), counting),
        r.kernel.run(request({ idempotencyKey: idempotencyKey('I2') }), counting),
      ]);
      const won = [a, b].filter((o) => o.claimed).length;
      return eq(won, 1, 'winners') ?? eq(effects, 1, 'external effects');
    },
  },
  {
    id: 'NP-NC-08', name: 'same intent replayed produces no second external effect',
    run: async () => {
      const r = rig();
      let effects = 0;
      const counting = async (req: Parameters<typeof r.effect>[0], tok: Parameters<typeof r.effect>[1]) => {
        effects++; return r.effect(req, tok);
      };
      await r.kernel.run(request(), counting);
      const again = await r.kernel.run(request({ transitionId: transitionId('T1-retry'), approval: approval({ transitionId: transitionId('T1-retry') }) }), counting);
      return eq(effects, 1, 'external effects') ?? eq(again.duplicateSuppressed, true, 'duplicateSuppressed');
    },
  },
  {
    id: 'NP-NC-09', name: 'pre-state version changed after governance holds the transition',
    run: async () => {
      const r = rig();
      r.resources.driftVersion(TARGET);     // another process writes v18
      const o = await r.kernel.run(request(), r.effect);
      return eq(o.reason, 'STALE_RESOURCE_VERSION', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-10', name: 'accepted command with unchanged state is DEVIATION, not VERIFIED',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request(), r.noopEffect);   // returns accepted:true, changes nothing
      return eq(o.executed, true, 'executed') ?? eq(o.verification, 'DEVIATION', 'verification');
    },
  },
  {
    id: 'NP-NC-11', name: 'recovery passes the full governance path',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({
        transitionId: transitionId('T1-recovery'), recoveryOf: transitionId('T1'),
        actor: OUTSIDER, approval: approval({ transitionId: transitionId('T1-recovery') }),
      }), r.effect);
      return eq(o.reason, 'TENANT_ISOLATION_VIOLATION', 'recovery was governed') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-12', name: 'AI cannot authorize its own action',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({ actor: AI, approval: undefined, consequence: 'C1' }), r.effect);
      return eq(o.reason, 'MODEL_SELF_AUTHORIZATION', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-20', name: 'a relationship-governed action with NO relationship context is denied',
    run: async () => {
      const r = rig();
      // OMITTED, not empty: "nobody looked" must not read as "none exists" (L-07).
      const o = await r.kernel.run(request({ relationships: undefined }), r.effect);
      return eq(o.reason, 'RELATIONSHIP_CONTEXT_MISSING', 'reason') ?? eq(o.executed, false, 'executed')
        ?? eq(o.relationshipAssessment, 'UNASSESSED', 'assessment state');
    },
  },
  {
    id: 'NP-NC-21', name: 'an EMPTY relationship declaration is accepted — it is an answer',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({ relationships: [] }), r.effect);
      return eq(o.verdict, 'ALLOW', 'verdict') ?? eq(o.executed, true, 'executed')
        ?? eq(o.relationshipAssessment, 'ASSESSED_NONE_FOUND', 'assessment state');
    },
  },
  {
    id: 'NP-NC-23',
    name: 'an action the profile does NOT relationship-govern reports NOT_APPLICABLE, never UNASSESSED',
    run: async () => {
      // NPC-23 / NPL-17: relationship context is declared per action. An action
      // that does not require it must NOT be denied — and its record must not be
      // silent either, or NOT_APPLICABLE and UNASSESSED become indistinguishable.
      const r = rig({}, { relationshipActions: new Set<string>() });
      const o = await r.kernel.run(request({ relationships: undefined }), r.effect);
      return eq(o.verdict, 'ALLOW', 'verdict') ?? eq(o.executed, true, 'executed')
        ?? eq(o.relationshipAssessment, 'NOT_APPLICABLE', 'assessment state');
    },
  },
  {
    id: 'NP-NC-24',
    name: 'a CONTRADICTED relationship holds the transition — asserted is not observed',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({
        relationships: [{ kind: 'account-owner', subject: 'party-77', object: 'customer:123',
          source: 'crm', observedAt: T0, epistemicStatus: 'CONTRADICTED' }],
      }), r.effect);
      return eq(o.reason, 'RELATIONSHIP_EPISTEMIC_INSUFFICIENT', 'reason')
        ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-22', name: 'stale relationship context holds the transition, never proceeds',
    run: async () => {
      const r = rig();
      const o = await r.kernel.run(request({
        relationships: [{ kind: 'account-owner', subject: 'party-77', object: 'customer:123',
          source: 'crm', observedAt: T0 - 7_200_000 }],   // two hours old, limit is one
      }), r.effect);
      return eq(o.reason, 'RELATIONSHIP_CONTEXT_STALE', 'reason') ?? eq(o.executed, false, 'executed');
    },
  },
  {
    id: 'NP-NC-25',
    name: 'an observation OF ANOTHER SUBJECT does not verify this transition',
    run: async () => {
      // NPL-23. The observation is TRUE — something really is SUSPENDED. It is
      // simply not an observation of customer 123. A true statement about the
      // wrong thing must yield UNKNOWN: never VERIFIED, and never DEVIATION,
      // because we learned nothing about our target either way.
      const r = rig();
      const wired: typeof r.effect = async (req, token) => {
        const ok = r.resources.compareAndSet(
          req.target, req.target.version, req.expectedPostState, token);
        r.resources.misbindSubject(req.target, 'tenant-A/customer/456');
        return { accepted: ok };
      };
      const o = await r.kernel.run(request(), wired);
      return eq(o.verification, 'UNKNOWN', 'verification')
        ?? eq(o.outcomeClass, 'UNKNOWN', 'outcome class')
        ?? eq(o.verificationProposition?.subject, 'tenant-A/customer/456', 'proposition subject');
    },
  },
  {
    id: 'NP-NC-26',
    name: 'every verification verdict carries the proposition it is a verdict about',
    run: async () => {
      // NPL-22. "VERIFIED" with nothing to point at is a word, not a finding.
      const r = rig();
      const o = await r.kernel.run(request(), r.effect);
      const p = o.verificationProposition;
      if (!p) return 'no verification proposition on a verified outcome';
      return eq(o.verification, 'VERIFIED', 'verification')
        ?? eq(p.subject, 'tenant-A/customer/123', 'subject')
        ?? eq(p.expected, 'SUSPENDED', 'expected')
        ?? eq(p.relation, 'STRUCTURAL_EQUALITY', 'relation')
        ?? eq(typeof p.source === 'string' && p.source.length > 0, true, 'source')
        ?? eq(p.at > 0, true, 'at');
    },
  },
  {
    id: 'NP-NC-27',
    name: 'a refused effect with an unchanged post-state is VERIFIED_FAILURE, not UNKNOWN',
    run: async () => {
      // NPL-18/20. Establishing that the intended effect did NOT occur is a
      // positive finding. Collapsing it into UNKNOWN loses the fact that we know.
      const r = rig();
      const refuse: typeof r.effect = async () => ({ accepted: false });
      const o = await r.kernel.run(request(), refuse);
      return eq(o.outcomeClass, 'VERIFIED_FAILURE', 'outcome class')
        ?? eq(o.verification, 'DEVIATION', 'verification')
        ?? eq(o.verificationProposition?.observed, 'ACTIVE', 'observed post-state');
    },
  },
];

/** The positive path must also hold, or the controls could be passing vacuously. */
const HAPPY: Case = {
  id: 'NP-CST-92', name: 'reference transition: ACTIVE → SUSPENDED, VERIFIED',
  run: async () => {
    const r = rig();
    const o = await r.kernel.run(request(), r.effect);
    return eq(o.verdict, 'ALLOW', 'verdict')
      ?? eq(o.executed, true, 'executed')
      ?? eq(o.verification, 'VERIFIED', 'verification')
      ?? eq(r.resources.observe(TARGET)?.state, 'SUSPENDED', 'post-state')
      ?? eq(r.resources.observe(TARGET)?.version, 18, 'version')
      ?? eq(r.evidence.forTransition("T1").length >= 4, true, 'evidence records');
  },
};

if (import.meta.url === `file://${process.argv[1]}`) {
  const failed = await runAll('NPMS-1.2 — BASE NEGATIVE CONTROLS', [HAPPY, ...CONTROLS]);
  console.log('Scope: the reference fixture only. Coverage of other transitions: NOT ESTABLISHED.');
  process.exit(failed ? 1 : 0);
}
