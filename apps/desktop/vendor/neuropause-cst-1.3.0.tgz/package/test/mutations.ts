/**
 * NP-CST-91 / MSD-L-12 — the mutation suite for the negative controls.
 *
 * For each control, the guard it tests is disabled and the control MUST then
 * fail. A control that still passes with its guard removed proves nothing, and
 * is reported as NOT PROVEN rather than counted as working.
 */
import { CONTROLS } from './negative-controls.js';
import { MUTATION } from './fixture.js';
import type { Guards } from '../src/kernel.js';

/** Which guard each control depends on. One control, one guard, no overlap. */
const GUARD_FOR: Readonly<Record<string, keyof Guards>> = {
  'NP-NC-01': 'actorAuthorized',
  'NP-NC-02': 'tenantIsolation',
  'NP-NC-03': 'approvalExpiry',
  'NP-NC-04': 'approvalBinding',
  'NP-NC-05': 'approvalScope',
  'NP-NC-06': 'evidenceFreshness',
  'NP-NC-07': 'atomicClaim',
  'NP-NC-08': 'idempotency',
  'NP-NC-09': 'preStateRevalidation',
  'NP-NC-10': 'postconditionVerification',
  'NP-NC-11': 'recoveryGoverned',
  'NP-NC-12': 'modelCannotSelfAuthorize',
  'NP-NC-20': 'relationshipContext',
  'NP-NC-22': 'relationshipContext',
  'NP-NC-24': 'relationshipContext',
  'NP-NC-25': 'observationSubjectBinding',
};

// The fixture reads the disabled guard from MUTATION. The control tests are
// unmodified; only the kernel configuration changes — so a mutation cannot be
// satisfied by rewriting an assertion.

const run = async () => {
  console.log('\nMUTATION SUITE — BASE CONTROLS\n' + '='.repeat(76));
  let proven = 0, skipped = 0;
  for (const c of CONTROLS) {
    const guard = GUARD_FOR[c.id];
    if (!guard) {
      // NP-NC-21 asserts an ACCEPTANCE, not a refusal: an empty declaration is a
      // valid answer. Removing a guard cannot make an acceptance fail, so it has
      // no guard-removal mutation and is reported, never silently skipped (H-7).
      console.log(`${c.id.padEnd(10)} ${'N/A'.padEnd(12)}asserts acceptance — no guard-removal mutation exists`);
      skipped++; continue;
    }
    MUTATION.disabled = guard;
    let stillPasses: boolean;
    try { stillPasses = (await c.run()) === null; } catch { stillPasses = false; }
    MUTATION.disabled = null;
    if (!stillPasses) proven++;
    console.log(
      `${c.id.padEnd(10)} ${(stillPasses ? 'NOT PROVEN' : 'DETECTED').padEnd(12)}` +
      `guard removed: ${guard}`,
    );
  }
  console.log('='.repeat(76));
  console.log(`controls with a proven detection: ${proven}/${CONTROLS.length - skipped}`
    + (skipped ? `  (${skipped} assert acceptance, no mutation applicable)` : ''));
  console.log('DETECTION COMPLETENESS: NOT ESTABLISHED — this suite covers only the');
  console.log('declared guard-removal class, on the reference fixture, in this environment.');
  process.exit(proven === CONTROLS.length - skipped ? 0 : 1);
};

await run();
