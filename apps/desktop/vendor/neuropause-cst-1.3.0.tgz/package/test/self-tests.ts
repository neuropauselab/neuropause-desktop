/**
 * §35 — self-tests for the simulation itself.
 *
 * NP-TEST-LAW-02: a zero-violation result establishes assurance only when the
 * test demonstrably exercised the condition capable of producing the violation.
 * These six assertions are what make that demonstrable. They must run BEFORE the
 * invariant results are believed.
 */
import { runAll, eq, type Case } from './harness.js';
import { ClaimStore, EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime } from '../src/stores.js';
import { DurableStore } from '../src/durable.js';
import { CstKernel } from '../src/kernel.js';
import { ErpPaymentAdapter, type PaymentCommand } from '../src/payment.js';
import { approvalId, transitionId, type Actor, type Approval } from '../src/types.js';
import { HostileRail, Rng } from './hostile-rail.js';
import { ShadowEffect, evaluatePromotion, UNDECLARED_RAIL } from '../src/shadow.js';

const T0 = 1_760_000_000_000;
const CLERK: Actor = { id: 'c', type: 'HUMAN', tenantId: 't' };
const MGR: Actor = { id: 'm', type: 'HUMAN', tenantId: 't' };

const rig = (railOpts: Partial<Parameters<typeof HostileRail.prototype.submit>[0]> = {}) => {
  void railOpts;
  const time = new SystemTime(T0);
  const rng = new Rng(7);
  const rail = new HostileRail(rng, {
    nonIdempotent: true, loseResponsePr: 0, rejectPr: 0,
    stallPr: 0, reversePr: 0, statusBlindPr: 1,      // blind: cannot reconcile
  }, () => time.now());
  const resources = new ResourceStore();
  resources.put({ tenantId: 't', resourceType: 'payment', resourceId: 'P', version: 1 }, 'READY');
  const evidence = new EvidenceStore();
  const policy = new PolicyStore(new Map([['c', new Set(['PAYMENT.EXECUTE'])]]), 'p:1', new Set());
  const holder: { a?: ErpPaymentAdapter } = {};
  let idem = new IdempotencyStore();
  const mk = () => {
    const kernel = new CstKernel({ time, policy, claims: new ClaimStore(), idempotency: idem,
      resources, evidence, reconcile: async (k) => holder.a!.reconciler(k) });
    const a = new ErpPaymentAdapter({ kernel, provider: rail, resources, time, evidence });
    holder.a = a; return a;
  };
  const approval: Approval = {
    approvalId: approvalId('A'), transitionId: transitionId('pay-t-P'), approver: MGR,
    action: 'PAYMENT.EXECUTE', scope: { tenantId: 't', resourceType: 'payment', resourceId: 'P' },
    resourceVersion: 1, purpose: 'x', policyVersion: 'p:1', issuedAt: T0,
    expiresAt: T0 + 3_600_000, consumed: false,
  };
  const cmd = (): PaymentCommand => ({
    tenantId: 't', paymentId: 'P', paymentVersion: 1, amountMinor: 100, currency: 'INR',
    payeeId: 'v', actor: CLERK, purpose: 'x', approval,
    evidenceObservedAt: T0, evidenceFreshnessMs: 3_600_000,
  });
  return { time, rail, mk, cmd, wipeIntent: () => { idem = new IdempotencyStore(); }, evidence };
};

const CASES: readonly Case[] = [
  { id: 'ST-1', name: 'concurrency self-test: some attempts genuinely overlap', run: async () => {
      const r = rig(); const a = r.mk();
      const pair = await Promise.all([a.execute(r.cmd()), a.execute(r.cmd())]);
      return eq(pair.filter((o) => o.reason === 'CLAIM_LOST').length, 1, 'lost claims');
  } },
  { id: 'ST-2', name: 'retry self-test: more than one attempt can reach the rail', run: async () => {
      const r = rig(); let a = r.mk();
      await a.execute(r.cmd());
      r.wipeIntent(); a = r.mk();                    // restart
      await a.execute(r.cmd());
      return r.rail.submissions.length >= 2 ? null : `only ${r.rail.submissions.length} submissions`;
  } },
  { id: 'ST-3', name: 'crash self-test: the wipe destroys what a real restart destroys', run: async () => {
      const r = rig(); let a = r.mk();
      await a.execute(r.cmd());
      r.wipeIntent(); a = r.mk();
      const after = await a.execute(r.cmd());
      // with the intent lost and the rail blind, the kernel must NOT report a
      // suppressed duplicate — it has no basis for one
      return after.duplicateSuppressed ? 'reported a duplicate it could not know about' : null;
  } },
  { id: 'ST-4', name: 'unknown self-test: UNKNOWN outcomes actually occur', run: async () => {
      const r = rig(); const a = r.mk();
      const o = await a.execute(r.cmd());
      return o.verification === 'UNKNOWN' ? null : `verification was ${o.verification}`;
  } },
  { id: 'ST-5', name: 'rail self-test: the hostile rail genuinely permits duplicates', run: async () => {
      const r = rig();
      await r.rail.submit({ idempotencyKey: 'k', amountMinor: 1, fencingToken: 1 });
      await r.rail.submit({ idempotencyKey: 'k', amountMinor: 1, fencingToken: 2 });
      return r.rail.settledCountFor('k') >= 2 ? null : 'rail deduped — it cannot expose the hazard';
  } },
  { id: 'ST-6', name: 'oracle self-test: effects counted by the rail, not by the kernel', run: async () => {
      const r = rig(); const a = r.mk();
      const o = await a.execute(r.cmd());
      // the kernel reports one execution; the ORACLE is the rail ledger
      return eq(r.rail.ledger.length, 1, 'rail ledger entries')
        ?? (o.executed ? null : 'kernel disagreed, which is fine — the rail decides');
  } },
  { id: 'ST-7', name: 'durable store: two callers, one winner, at the storage engine', run: async () => {
      const d = new DurableStore(':memory:');
      const a = d.claimAtomic('k', 'w1');
      const b = d.claimAtomic('k', 'w2');
      const won = [a, b].filter((c) => c.won).length;
      d.close();
      return eq(won, 1, 'winners');
  } },
  { id: 'ST-8', name: 'shadow effect never reports acceptance', run: async () => {
      const s = new ShadowEffect(() => T0);
      const res = await s.effect({ transitionId: transitionId('x'), idempotencyKey: 'k' } as never, 1 as never);
      return eq(res.accepted, false, 'accepted') ?? eq(s.records.length, 1, 'records');
  } },
  /**
   * NP-MS-160 / D-16. ST-8 used to CLAIM this in its name and never assert it —
   * the same defect class as D-5, in our own suite. The safety of shadow mode is
   * not that it returns accepted:false; it is that the adapter was never handed
   * anything it could call. So assert THAT, structurally.
   */
  { id: 'ST-10', name: 'shadow effect retains nothing callable — no provider, at any depth', run: async () => {
      const s = new ShadowEffect(() => T0);
      const SUSPECT = ['submit', 'execute', 'charge', 'post', 'send', 'delete', 'request'];
      const seen = new Set<unknown>();
      const walk = (v: unknown, path: string, depth: number): string | null => {
        if (depth > 4 || v === null || seen.has(v)) return null;
        if (typeof v === 'object' || typeof v === 'function') {
          seen.add(v);
          for (const m of SUSPECT) {
            if (typeof (v as Record<string, unknown>)[m] === 'function') {
              return `shadow adapter retains a callable boundary at ${path}.${m}()`;
            }
          }
          for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
            const r = walk(val, `${path}.${k}`, depth + 1);
            if (r) return r;
          }
        }
        return null;
      };
      const retained = walk(s, 'shadow', 0);
      if (retained) return retained;
      // and the constructor takes exactly one argument: the clock. A provider
      // cannot be threaded in without changing this number.
      return eq(ShadowEffect.length, 1, 'ShadowEffect constructor arity');
  } },
  { id: 'ST-9', name: 'an undeclared rail blocks promotion', run: async () => {
      const d = evaluatePromotion({ rail: UNDECLARED_RAIL, durableIntent: true,
        crossProcessOwnership: true, erpStatesMapped: true });
      return d.permitted ? 'promotion permitted with an undeclared rail' : null;
  } },
];

const failed = await runAll('SIMULATION SELF-TESTS — §35 / NP-TEST-LAW-02', CASES);
console.log('These must pass BEFORE any invariant result is believed.');
process.exit(failed ? 1 : 0);
