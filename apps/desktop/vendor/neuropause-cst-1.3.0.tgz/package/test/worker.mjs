// One OS process. Claims the shared transition key, optionally hangs so it can
// be SIGKILLed while holding the claim, then releases.
import { DurableStore } from '../dist/src/durable.js';
const [, , dbPath, workerId, mode] = process.argv;
const s = new DurableStore(dbPath);
const r = s.claimAtomic('T-shared', workerId);
process.stdout.write(JSON.stringify({ workerId, won: r.won, token: r.fencingToken, owner: r.owner }) + '\n');
if (r.won && mode === 'hang') {
  setTimeout(() => {}, 60_000);          // hold the claim and wait to be killed
} else {
  // In race mode the winner does NOT release. Releasing frees the key for the
  // next process, so several would win in sequence and the test would measure
  // scheduling order rather than exclusivity — a flaky test, which is itself a
  // defect: it fails randomly in CI and then gets disabled.
  s.close();
}
