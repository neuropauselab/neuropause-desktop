/** PH-9.13 — mutation suite for the camera-delete controls. */
import { CAM_CONTROLS, MUTATION } from './neurolook.js';
import type { Guards } from '../src/kernel.js';

const GUARD_FOR: Readonly<Record<string, keyof Guards>> = {
  'NP-NC-02': 'tenantIsolation',
  'NP-NC-03': 'approvalExpiry',
  'NP-NC-12': 'modelCannotSelfAuthorize',
  'NP-NC-14': 'constraintsEnforced',
  'NP-NC-15': 'separationOfDuties',
  'NP-NC-17': 'postconditionVerification',
  'NP-NC-18': 'postconditionVerification',
  'NP-NC-19': 'postconditionVerification',
};

console.log('\nPH-9.13 MUTATION SUITE — CAMERA DELETE\n' + '='.repeat(76));
let proven = 0, mapped = 0;
for (const c of CAM_CONTROLS) {
  const g = GUARD_FOR[c.id];
  if (!g) { console.log(`${c.id.padEnd(10)} NO GUARD MAPPED`); continue; }
  mapped++;
  MUTATION.disabled = g;
  let ok: boolean;
  try { ok = (await c.run()) === null; } catch { ok = false; }
  MUTATION.disabled = null;
  if (!ok) proven++;
  console.log(`${c.id.padEnd(10)} ${(ok ? 'NOT PROVEN' : 'DETECTED').padEnd(12)}guard removed: ${g}`);
}
console.log('='.repeat(76));
console.log(`controls with a proven detection: ${proven}/${mapped}`);
console.log('DETECTION COMPLETENESS: NOT ESTABLISHED');
process.exit(proven === mapped ? 0 : 1);
