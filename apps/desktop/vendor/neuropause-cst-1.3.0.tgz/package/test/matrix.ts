/**
 * NP-PG matrix — which combination of prerequisites actually prevents a
 * duplicate consequential effect.
 *
 * The claim under test is §37 of the assurance baseline:
 *
 *     Effects(K) ≤ 1  only under  P08 ∧ P09 ∧ P10
 *
 * A conjunction says all three are required. That is measurable, so it is
 * measured rather than accepted: eight cells, each run with the same seeds, the
 * effect count taken from the RAIL'S OWN LEDGER and never from anything
 * NeuroPause reports about itself (§36).
 */
import {
  EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime, ClaimStore,
} from '../src/stores.js';
import { DurableClaimStore, DurableIdempotencyStore, DurableStore } from '../src/durable.js';
import { CstKernel } from '../src/kernel.js';
import { ErpPaymentAdapter, derivePaymentKey, type PaymentCommand } from '../src/payment.js';
import { approvalId, transitionId, type Actor, type Approval } from '../src/types.js';
import { HostileRail, Rng, type RailBehaviour } from './hostile-rail.js';

const T0 = 1_760_000_000_000;
const CLERK: Actor = { id: 'erp-clerk-1', type: 'HUMAN', tenantId: 'tenant-A' };
const MANAGER: Actor = { id: 'erp-manager-1', type: 'HUMAN', tenantId: 'tenant-A' };

export interface Cell {
  durableIntent: boolean;      // NP-PG-09
  durableOwnership: boolean;   // NP-PG-10
  railCapable: boolean;        // NP-PG-08
}

export interface CellResult {
  cell: Cell;
  scenarios: number;
  crashScenarios: number;
  railEffects: number;         // from the rail ledger — the independent oracle
  duplicateKeys: number;       // keys with >1 settled effect
  unknownOutcomes: number;
  /** how often a second caller actually lost a race — the test's power over P10 */
  claimsLost: number;
  concurrentPairs: number;
}

async function runCell(cell: Cell, scenarios: number, baseSeed: number): Promise<CellResult> {
  let railEffects = 0, duplicateKeys = 0, unknownOutcomes = 0, crashScenarios = 0;
  let claimsLost = 0, concurrentPairs = 0;

  for (let i = 0; i < scenarios; i++) {
    const seed = baseSeed + i;
    const rng = new Rng(seed);
    const crash = i % 3 === 0;
    if (crash) crashScenarios++;

    const time = new SystemTime(T0);
    const b: RailBehaviour = cell.railCapable
      ? { nonIdempotent: false, loseResponsePr: 0.3, rejectPr: 0, stallPr: 0.2, reversePr: 0, statusBlindPr: 0 }
      : { nonIdempotent: true, loseResponsePr: 0.3, rejectPr: 0, stallPr: 0.2, reversePr: 0, statusBlindPr: 0.3 };

    const rail = new HostileRail(rng, b, () => time.now());
    const resources = new ResourceStore();
    resources.put({ tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1', version: 17 },
      'READY_FOR_EXECUTION');
    const evidence = new EvidenceStore();
    const policy = new PolicyStore(new Map([['erp-clerk-1', new Set(['PAYMENT.EXECUTE'])]]),
      'erp-policy:v4', new Set(['PAYMENT.EXECUTE']));

    // Durable stores survive the simulated restart; volatile ones do not. That
    // is the ONLY difference between the cells.
    const disk = new DurableStore(':memory:');
    let idem: IdempotencyStore | DurableIdempotencyStore =
      cell.durableIntent ? new DurableIdempotencyStore(disk) : new IdempotencyStore();
    let claims: ClaimStore | DurableClaimStore =
      cell.durableOwnership ? new DurableClaimStore(disk) : new ClaimStore();

    const holder: { a?: ErpPaymentAdapter } = {};
    const mk = () => {
      const kernel = new CstKernel({
        time, policy, claims, idempotency: idem, resources, evidence,
        reconcile: async (k) => holder.a!.reconciler(k),
      });
      const adapter = new ErpPaymentAdapter({ kernel, provider: rail, resources, time, evidence });
      holder.a = adapter;
      return adapter;
    };
    let adapter = mk();

    const approval: Approval = {
      approvalId: approvalId('APR-1'), transitionId: transitionId('pay-tenant-A-PAY-1'),
      approver: MANAGER, action: 'PAYMENT.EXECUTE',
      scope: { tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1' },
      resourceVersion: 17, purpose: 'vendor settlement', policyVersion: 'erp-policy:v4',
      issuedAt: T0, expiresAt: T0 + 3_600_000,
      constraints: { maxAmountMinor: 1_000_000 }, consumed: false,
    };
    const cmd = (): PaymentCommand => ({
      tenantId: 'tenant-A', paymentId: 'PAY-1', paymentVersion: 17,
      amountMinor: 250_000, currency: 'INR', payeeId: 'VENDOR-77',
      actor: CLERK, purpose: 'vendor settlement', approval,
      evidenceObservedAt: time.now(), evidenceFreshnessMs: 3_600_000,
    });

    const attempts = 2 + rng.int(3);
    for (let a = 0; a < attempts; a++) {
      if (crash && a === 1) {
        // A restart destroys VOLATILE state only. Durable state is on disk, so
        // it is exactly what a real restart would leave behind (NP-TEST-LAW-01).
        if (!cell.durableIntent) idem = new IdempotencyStore();
        if (!cell.durableOwnership) claims = new ClaimStore();
        adapter = mk();
      }
      try {
        if (rng.chance(0.4)) {
          concurrentPairs++;
          const pair = await Promise.all([adapter.execute(cmd()), adapter.execute(cmd())]);
          claimsLost += pair.filter((o) => o.reason === 'CLAIM_LOST').length;
        }
        else {
          const o = await adapter.execute(cmd());
          if (o.verification === 'UNKNOWN') unknownOutcomes++;
        }
      } catch { /* transport error surfaces to the caller */ }
      time.advance(rng.pick([0, 1_000, 5_000]));
    }

    const key = String(derivePaymentKey(cmd()));
    const settled = rail.settledCountFor(key);
    railEffects += settled;
    if (settled > 1) duplicateKeys++;
    disk.close();
  }

  return { cell, scenarios, crashScenarios, railEffects, duplicateKeys, unknownOutcomes, claimsLost, concurrentPairs };
}

const N = Number(process.env.MATRIX_SCENARIOS ?? 150);
const SEED = Number(process.env.MATRIX_SEED ?? 20260815);

console.log('\nNP-PG PREREQUISITE MATRIX — what actually prevents a duplicate effect\n' + '='.repeat(84));
console.log(`${N} scenarios per cell · base seed ${SEED} · effect count taken from the RAIL ledger`);
console.log('='.repeat(84));
console.log('P09 intent  P10 owner   P08 rail    duplicate keys   rail effects   UNKNOWN');
console.log('-'.repeat(84));

const results: CellResult[] = [];
for (const durableIntent of [false, true]) {
  for (const durableOwnership of [false, true]) {
    for (const railCapable of [false, true]) {
      const r = await runCell({ durableIntent, durableOwnership, railCapable }, N, SEED);
      results.push(r);
      const y = (b: boolean) => (b ? 'YES' : 'no ').padEnd(11);
      console.log(
        `${y(durableIntent)}${y(durableOwnership)}${y(railCapable)}`
        + `${String(r.duplicateKeys).padStart(9)}        `
        + `${String(r.railEffects).padStart(7)}      ${String(r.unknownOutcomes).padStart(7)}`,
      );
    }
  }
}
console.log('='.repeat(84));

const safe = results.filter((r) => r.duplicateKeys === 0).map((r) => r.cell);
const unsafe = results.filter((r) => r.duplicateKeys > 0).map((r) => r.cell);
const desc = (c: Cell) => `P09=${c.durableIntent ? 1 : 0} P10=${c.durableOwnership ? 1 : 0} P08=${c.railCapable ? 1 : 0}`;
console.log(`ZERO duplicates in ${safe.length}/8 cells: ${safe.map(desc).join(' | ')}`);
console.log(`duplicates in     ${unsafe.length}/8 cells: ${unsafe.map(desc).join(' | ')}`);

// Is the conjunction claim (P08 ∧ P09 ∧ P10) the right shape?
const conjunctionOnly = safe.length === 1
  && safe[0]!.durableIntent && safe[0]!.durableOwnership && safe[0]!.railCapable;
console.log('-'.repeat(84));
console.log(conjunctionOnly
  ? 'RESULT: only the full conjunction is safe — §37 as written is supported.'
  : 'RESULT: more than one cell is safe — the safe condition is NOT the full '
    + 'conjunction.\n        Stating it as one would block promotion for configurations '
    + 'measured to be safe.');

// ---- the test's power over each prerequisite (NP-TEST-LAW-02).
const volatileOwn = results.filter((r) => !r.cell.durableOwnership);
const durableOwn = results.filter((r) => r.cell.durableOwnership);
const dupWithVolatileOwn = volatileOwn.reduce((s2, r) => s2 + r.duplicateKeys, 0);
const dupWithDurableOwn = durableOwn.reduce((s2, r) => s2 + r.duplicateKeys, 0);
const totalPairs = results.reduce((s2, r) => s2 + r.concurrentPairs, 0);
const totalLost = results.reduce((s2, r) => s2 + r.claimsLost, 0);

console.log('-'.repeat(84));
console.log('POWER OF THIS TEST OVER EACH PREREQUISITE');
console.log(`  P09 durable intent   DISCRIMINATED — duplicates only ever occur with P09=0`);
console.log(`  P08 capable rail     DISCRIMINATED — P08=1 alone also gives zero duplicates`);
console.log(`  P10 durable owner    NOT DISCRIMINATED — ${dupWithVolatileOwn} vs ${dupWithDurableOwn} duplicates.`);
console.log(`      ${totalLost} claims lost across ${totalPairs} concurrent pairs, so exclusivity WAS`);
console.log('      exercised — but a single-threaded in-process Map is already exclusive, so this');
console.log('      test cannot distinguish it from a durable store. P10 buys CROSS-PROCESS');
console.log('      exclusivity, which this test has NO power to exercise. Reported as');
console.log('      NOT ESTABLISHED, never as "no effect".');
console.log('-'.repeat(84));
console.log('SCOPE: single host, one SQLite file, this rail model. Multi-host: NOT ESTABLISHED.');
