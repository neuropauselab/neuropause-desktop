/** PH-9 — the SAME kernel, a C4 irreversible action. */
import { runAll, eq, type Case } from './harness.js';
import { ClaimStore, EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime } from '../src/stores.js';
import { CstKernel, type Guards } from '../src/kernel.js';
import { NeuroLookCameraAdapter, type CameraCommand, type CameraProbe, type CameraStore } from '../src/camera.js';
import { approvalId, transitionId, type Actor, type Approval } from '../src/types.js';

const T0 = 1_760_000_000_000;
const OP: Actor = { id: 'nl-op-1', type: 'HUMAN', tenantId: 'site-A' };
const MGR: Actor = { id: 'nl-mgr-1', type: 'HUMAN', tenantId: 'site-A' };
const AGENT: Actor = { id: 'nl-agent', type: 'AI', tenantId: 'site-A' };
const OTHER: Actor = { id: 'nl-op-9', type: 'HUMAN', tenantId: 'site-B' };

export const MUTATION: { disabled: keyof Guards | null } = { disabled: null };

class FakeRegistry implements CameraStore {
  deletes = 0;
  #done = new Set<string>();
  probeMode: CameraProbe['kind'] = 'TOMBSTONE';
  async delete(cmd: { idempotencyKey: string }) {
    this.deletes++; this.#done.add(cmd.idempotencyKey);
    return { accepted: true, receipt: `rcpt-${this.deletes}` };
  }
  async probe(): Promise<CameraProbe> {
    if (this.probeMode === 'TOMBSTONE') return { kind: 'TOMBSTONE', deletedAt: T0, by: 'nl-op-1' };
    if (this.probeMode === 'PRESENT') return { kind: 'PRESENT', state: 'ACTIVE' };
    return { kind: this.probeMode } as CameraProbe;
  }
  async lookupByKey(key: string) { return this.#done.has(key) ? { found: true } : { found: false }; }
}

function rig() {
  const applied: Partial<Guards> = {};
  if (MUTATION.disabled) applied[MUTATION.disabled] = false;
  const time = new SystemTime(T0);
  const resources = new ResourceStore();
  resources.put({ tenantId: 'site-A', resourceType: 'camera', resourceId: 'CAM-7', version: 3 }, 'ACTIVE');
  const evidence = new EvidenceStore();
  const store = new FakeRegistry();
  const policy = new PolicyStore(new Map([
    ['nl-op-1', new Set(['CAMERA.DELETE'])], ['nl-op-9', new Set(['CAMERA.DELETE'])],
    ['nl-agent', new Set(['CAMERA.DELETE'])],
  ]), 'neurolook-policy:v2', new Set(['CAMERA.DELETE']));
  const holder: { a?: NeuroLookCameraAdapter } = {};
  const kernel = new CstKernel({ time, policy, claims: new ClaimStore(), idempotency: new IdempotencyStore(),
    resources, evidence, guards: applied, reconcile: async (k) => holder.a!.reconciler(k) });
  const adapter = new NeuroLookCameraAdapter({ kernel, store, resources, time, evidence });
  holder.a = adapter;
  return { time, store, adapter, resources, evidence };
}

const approval = (o: Partial<Approval> = {}): Approval => ({
  approvalId: approvalId('NLA-1'), transitionId: transitionId('camdel-site-A-CAM-7'),
  approver: MGR, action: 'CAMERA.DELETE',
  scope: { tenantId: 'site-A', resourceType: 'camera', resourceId: 'CAM-7' },
  resourceVersion: 3, purpose: 'decommission', policyVersion: 'neurolook-policy:v2',
  issuedAt: T0, expiresAt: T0 + 600_000,
  constraints: { maxRetentionDaysRemaining: 0 },   // may only delete once retention has elapsed
  consumed: false, ...o,
} as Approval);

type Over<T> = { [K in keyof T]?: T[K] | undefined };
const cmd = (o: Over<CameraCommand> = {}): CameraCommand => ({
  tenantId: 'site-A', cameraId: 'CAM-7', cameraVersion: 3, retentionDaysRemaining: 0,
  actor: OP, purpose: 'decommission', approval: approval(),
  evidenceObservedAt: T0, evidenceFreshnessMs: 60_000, ...o,
} as CameraCommand);

export const CAM_CONTROLS: readonly Case[] = [
  { id: 'NP-NC-02', name: 'operator from another site cannot delete this camera', run: async () => {
      const r = rig(); const o = await r.adapter.execute(cmd({ actor: OTHER }));
      return eq(o.reason, 'TENANT_ISOLATION_VIOLATION', 'reason') ?? eq(r.store.deletes, 0, 'deletes');
  } },
  { id: 'NP-NC-03', name: 'expired approval cannot delete', run: async () => {
      const r = rig(); r.time.advance(700_000);
      const o = await r.adapter.execute(cmd());
      return eq(o.reason, 'APPROVAL_EXPIRED', 'reason') ?? eq(r.store.deletes, 0, 'deletes');
  } },
  { id: 'NP-NC-12', name: 'an AI-granted approval cannot authorise a C4 deletion', run: async () => {
      const r = rig(); const o = await r.adapter.execute(cmd({ actor: AGENT, approval: approval({ approver: AGENT }) }));
      return eq(o.reason, 'MODEL_SELF_AUTHORIZATION', 'reason') ?? eq(r.store.deletes, 0, 'deletes');
  } },
  { id: 'NP-NC-14', name: 'deletion refused while retention time remains', run: async () => {
      const r = rig(); const o = await r.adapter.execute(cmd({ retentionDaysRemaining: 12 }));
      return eq(o.reason, 'CONSTRAINT_EXCEEDED', 'ceiling reason') ?? eq(r.store.deletes, 0, 'deletes');
  } },
  { id: 'NP-NC-15', name: 'requester cannot approve their own C4 deletion', run: async () => {
      const r = rig(); const o = await r.adapter.execute(cmd({ approval: approval({ approver: OP }) }));
      return eq(o.reason, 'SEPARATION_OF_DUTIES', 'reason') ?? eq(r.store.deletes, 0, 'deletes');
  } },
  { id: 'NP-NC-17', name: 'NOT_FOUND does not verify a deletion — absence proves nothing', run: async () => {
      const r = rig(); r.store.probeMode = 'NOT_FOUND';
      const o = await r.adapter.execute(cmd());
      return eq(o.executed, true, 'executed') ?? eq(o.verification, 'UNKNOWN', 'verification');
  } },
  { id: 'NP-NC-18', name: 'UNREACHABLE registry does not verify a deletion either', run: async () => {
      const r = rig(); r.store.probeMode = 'UNREACHABLE';
      const o = await r.adapter.execute(cmd());
      return eq(o.verification, 'UNKNOWN', 'verification');
  } },
  { id: 'NP-NC-19', name: 'camera still PRESENT after delete is a DEVIATION', run: async () => {
      const r = rig(); r.store.probeMode = 'PRESENT';
      const o = await r.adapter.execute(cmd());
      return eq(o.verification, 'DEVIATION', 'verification') ?? eq(o.observedPostState, 'ACTIVE', 'observed');
  } },
];

const REF: Case = {
  id: 'REF-09', name: 'C4 deletion completes and is VERIFIED by a tombstone',
  run: async () => {
    const r = rig(); const o = await r.adapter.execute(cmd());
    return eq(o.verdict, 'ALLOW', 'verdict') ?? eq(o.executed, true, 'executed')
      ?? eq(o.verification, 'VERIFIED', 'verification') ?? eq(o.observedPostState, 'DELETED', 'observed')
      ?? eq(r.store.deletes, 1, 'registry deletes');
  },
};

if (import.meta.url === `file://${process.argv[1]}`) {
  const failed = await runAll('PH-9 — NEUROLOOK CAMERA DELETE · C4 IRREVERSIBLE · SAME KERNEL', [REF, ...CAM_CONTROLS]);
  console.log('Boundary: FakeRegistry (in-process). Real NeuroLook integration: NOT ESTABLISHED.');
  process.exit(failed ? 1 : 0);
}
