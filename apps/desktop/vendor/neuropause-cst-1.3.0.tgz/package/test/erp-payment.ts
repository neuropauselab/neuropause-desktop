/**
 * PH-8 — the fourteen controls against the ERP payment boundary.
 *
 * The provider below models a real payment rail: it accepts, it settles
 * asynchronously, it can lose a response after the effect has occurred, and it
 * can be looked up by idempotency key. That last behaviour is the only thing
 * that can resolve a lost response — NeuroPause cannot infer it.
 */
import { runAll, eq, type Case } from './harness.js';
import {
  ClaimStore, EvidenceStore, IdempotencyStore, PolicyStore, ResourceStore, SystemTime,
} from '../src/stores.js';
import { CstKernel, type Guards } from '../src/kernel.js';
import { ErpPaymentAdapter, derivePaymentKey, type PaymentCommand, type PaymentProvider, type PaymentState } from '../src/payment.js';
import { approvalId, transitionId, type Actor, type Approval } from '../src/types.js';

const T0 = 1_760_000_000_000;

const CLERK: Actor = { id: 'erp-clerk-1', type: 'HUMAN', tenantId: 'tenant-A' };
const AGENT: Actor = { id: 'erp-agent-1', type: 'AI', tenantId: 'tenant-A' };
const FOREIGN: Actor = { id: 'erp-clerk-9', type: 'HUMAN', tenantId: 'tenant-B' };
const NOGRANT: Actor = { id: 'erp-intern', type: 'HUMAN', tenantId: 'tenant-A' };

/** Set by the mutation suite. */
export const MUTATION: { disabled: keyof Guards | null } = { disabled: null };

class FakeRail implements PaymentProvider {
  submissions = 0;
  #byKey = new Map<string, { ref: string; state: PaymentState }>();
  #seq = 0;
  /** when true, submit performs the effect and then "loses" the response */
  loseResponse = false;
  /** when true, submit is accepted but the payment never leaves SUBMITTED */
  stallAtSubmitted = false;

  async submit(cmd: { idempotencyKey: string; fencingToken: number }) {
    this.submissions++;
    const existing = this.#byKey.get(cmd.idempotencyKey);
    if (existing) return { accepted: true, providerRef: existing.ref };   // rail-side idempotency
    const ref = `pref-${++this.#seq}`;
    this.#byKey.set(cmd.idempotencyKey, {
      ref, state: this.stallAtSubmitted ? 'SUBMITTED' : 'SETTLED',
    });
    if (this.loseResponse) throw new Error('network: response lost');
    return { accepted: true, providerRef: ref };
  }
  async statusOf(ref: string): Promise<PaymentState | 'UNKNOWN'> {
    for (const v of this.#byKey.values()) if (v.ref === ref) return v.state;
    return 'UNKNOWN';
  }
  async lookupByKey(key: string) {
    const hit = this.#byKey.get(key);
    return hit ? { found: true, providerRef: hit.ref } : { found: false };
  }
}

interface Rig {
  time: SystemTime; rail: FakeRail; adapter: ErpPaymentAdapter;
  resources: ResourceStore; evidence: EvidenceStore; idem: IdempotencyStore;
}

function rig(): Rig {
  const applied: Partial<Guards> = {};
  if (MUTATION.disabled) applied[MUTATION.disabled] = false;
  const time = new SystemTime(T0);
  const resources = new ResourceStore();
  resources.put({ tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1', version: 17 },
    'READY_FOR_EXECUTION');
  const evidence = new EvidenceStore();
  const idem = new IdempotencyStore();
  const rail = new FakeRail();
  const policy = new PolicyStore(new Map([
    ['erp-clerk-1', new Set(['PAYMENT.EXECUTE'])],
    ['erp-clerk-9', new Set(['PAYMENT.EXECUTE'])],
    ['erp-agent-1', new Set(['PAYMENT.EXECUTE'])],
  ]), 'erp-policy:v4', new Set(['PAYMENT.EXECUTE']));
  const adapterHolder: { a?: ErpPaymentAdapter } = {};
  const kernel = new CstKernel({
    time, policy, claims: new ClaimStore(), idempotency: idem, resources, evidence,
    guards: applied,
    reconcile: async (k) => adapterHolder.a!.reconciler(k),
  });
  const adapter = new ErpPaymentAdapter({ kernel, provider: rail, resources, time, evidence });
  adapterHolder.a = adapter;
  return { time, rail, adapter, resources, evidence, idem };
}

const approval = (over: Partial<Approval> = {}): Approval => ({
  approvalId: approvalId('APR-1'),
  transitionId: transitionId('pay-tenant-A-PAY-1'),
  approver: { id: 'erp-manager-1', type: 'HUMAN', tenantId: 'tenant-A' },
  action: 'PAYMENT.EXECUTE',
  scope: { tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1' },
  resourceVersion: 17,
  purpose: 'vendor settlement',
  policyVersion: 'erp-policy:v4',
  issuedAt: T0,
  expiresAt: T0 + 600_000,
  constraints: { maxAmountMinor: 1_000_000 },      // ₹10,000.00
  consumed: false,
  ...over,
} as Approval);

type Over<T> = { [K in keyof T]?: T[K] | undefined };

const cmd = (over: Over<PaymentCommand> = {}): PaymentCommand => ({
  tenantId: 'tenant-A', paymentId: 'PAY-1', paymentVersion: 17,
  amountMinor: 250_000, currency: 'INR', payeeId: 'VENDOR-77',
  actor: CLERK, purpose: 'vendor settlement', approval: approval(),
  evidenceObservedAt: T0, evidenceFreshnessMs: 60_000,
  ...over,
} as PaymentCommand);

export const PAY_CONTROLS: readonly Case[] = [
  { id: 'NP-NC-01', name: 'unauthorized principal cannot initiate payment', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ actor: NOGRANT }));
      return eq(o.reason, 'AUTHORIZATION_FAILURE', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-02', name: 'principal from another tenant cannot pay this payment', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ actor: FOREIGN }));
      return eq(o.reason, 'TENANT_ISOLATION_VIOLATION', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-03', name: 'expired approval cannot execute a payment', run: async () => {
      const r = rig(); r.time.advance(700_000);
      const o = await r.adapter.execute(cmd());
      return eq(o.reason, 'APPROVAL_EXPIRED', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-04', name: 'approval belonging to another payment cannot execute', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ approval: approval({ transitionId: transitionId('pay-tenant-A-PAY-2') }) }));
      return eq(o.reason, 'APPROVAL_MISMATCH', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-05', name: 'approval scoped to another payee/resource cannot execute', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ approval: approval({ scope: { tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-9' } }) }));
      return eq(o.reason, 'APPROVAL_SCOPE_VIOLATION', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-06', name: 'stale ledger evidence cannot satisfy the freshness requirement', run: async () => {
      const r = rig(); r.time.advance(90_000);
      const o = await r.adapter.execute(cmd());
      return eq(o.reason, 'EVIDENCE_STALE', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-07', name: 'two workers, one payment: exactly one submission', run: async () => {
      const r = rig();
      const [a, b] = await Promise.all([r.adapter.execute(cmd()), r.adapter.execute(cmd())]);
      // NP-NC-07 owns EXCLUSIVE OWNERSHIP. It must assert on the claim itself:
      // asserting on submissions makes it pass whenever any downstream control
      // (idempotency, preflight) happens to suppress the second effect, which
      // is the "passing for the wrong reason" class the mutation suite exists
      // to catch.
      const claimed = [a, b].filter((o) => o.claimed).length;
      const executed = [a, b].filter((o) => o.executed).length;
      return eq(claimed, 1, 'exclusive claim winners')
        ?? eq(executed, 1, 'executions')
        ?? eq(r.rail.submissions, 1, 'rail submissions');
  } },
  { id: 'NP-NC-08', name: 'retry of a completed payment creates no second payment', run: async () => {
      const r = rig();
      const first = await r.adapter.execute(cmd());
      const retry = await r.adapter.execute(cmd());
      return eq(first.verification, 'VERIFIED', 'first verification')
        ?? eq(r.rail.submissions, 1, 'rail submissions')
        ?? eq(retry.duplicateSuppressed, true, 'duplicateSuppressed')
        ?? eq(retry.executionId, first.executionId, 'original outcome returned');
  } },
  { id: 'NP-NC-09', name: 'payment cancelled between decision and execution blocks the effect', run: async () => {
      const r = rig();
      r.resources.driftVersion({ tenantId: 'tenant-A', resourceType: 'payment', resourceId: 'PAY-1' });
      const o = await r.adapter.execute(cmd());
      return eq(o.reason, 'STALE_RESOURCE_VERSION', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-10', name: 'rail accepts but payment stays SUBMITTED — DEVIATION, not VERIFIED', run: async () => {
      const r = rig(); r.rail.stallAtSubmitted = true;
      const o = await r.adapter.execute(cmd());
      return eq(o.executed, true, 'executed')
        ?? eq(o.verification, 'DEVIATION', 'verification')
        ?? eq(o.observedPostState, 'SUBMITTED', 'observed');
  } },
  { id: 'NP-NC-11', name: 'payment recovery re-enters the kernel and is governed', run: async () => {
      const r = rig();
      const o = await r.adapter.recover(cmd({ actor: FOREIGN }), transitionId('pay-tenant-A-PAY-1'));
      return eq(o.reason, 'TENANT_ISOLATION_VIOLATION', 'recovery governed')
        ?? eq(o.executed, false, 'executed')
        ?? eq(r.rail.submissions, 0, 'rail submissions');
  } },
  { id: 'NP-NC-12', name: 'an AI-granted approval cannot authorise the AI\'s own payment', run: async () => {
      const r = rig();
      const selfApproved = approval({ approver: AGENT });
      const o = await r.adapter.execute(cmd({ actor: AGENT, approval: selfApproved }));
      return eq(o.reason, 'MODEL_SELF_AUTHORIZATION', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-13', name: 'lost response is reconciled, never reported as a suppressed duplicate', run: async () => {
      const r = rig();
      r.rail.loseResponse = true;
      // first attempt: the rail records the payment, then the response is lost
      try { await r.adapter.execute(cmd()); } catch { /* the caller sees a network error */ }
      r.rail.loseResponse = false;
      const retry = await r.adapter.execute(cmd());
      return eq(r.rail.submissions, 1, 'rail submissions (no second payment)')
        ?? eq(retry.verification, 'VERIFIED', 'reconciled verification')
        ?? eq(retry.observedPostState, 'SETTLED', 'reconciled state');
  } },
  { id: 'NP-NC-14', name: 'approval for ₹10,000 does not authorise ₹1,00,000', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ amountMinor: 10_000_000 }));
      return eq(o.reason, 'CONSTRAINT_EXCEEDED', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
  { id: 'NP-NC-15', name: 'requester cannot also be the approver where policy declares SoD', run: async () => {
      const r = rig();
      const o = await r.adapter.execute(cmd({ approval: approval({ approver: CLERK }) }));
      return eq(o.reason, 'SEPARATION_OF_DUTIES', 'reason') ?? eq(r.rail.submissions, 0, 'submissions');
  } },
];

const REF: Case = {
  id: 'REF-01', name: 'valid payment completes end to end and is VERIFIED',
  run: async () => {
    const r = rig();
    const o = await r.adapter.execute(cmd());
    const key = derivePaymentKey(cmd());
    return eq(o.verdict, 'ALLOW', 'verdict')
      ?? eq(o.executed, true, 'executed')
      ?? eq(o.verification, 'VERIFIED', 'verification')
      ?? eq(o.observedPostState, 'SETTLED', 'authoritative post-state')
      ?? eq(r.rail.submissions, 1, 'rail submissions')
      ?? eq(typeof r.adapter.providerRefFor(key), 'string', 'provider ref recorded')
      ?? eq(r.evidence.forTransition('pay-tenant-A-PAY-1').length >= 4, true, 'evidence records');
  },
};

if (import.meta.url === `file://${process.argv[1]}`) {
  const failed = await runAll('PH-8 — ERP PAYMENT · CONSEQUENTIAL TRANSITION CONTROLS',
    [REF, ...PAY_CONTROLS]);
  console.log('Boundary: FakeRail (in-process). Real ERP integration: NOT ESTABLISHED.');
  process.exit(failed ? 1 : 0);
}
